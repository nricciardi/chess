#pragma once



namespace Chess {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Riepilogo per Start
	/// </summary>
	public ref class Setting : public System::Windows::Forms::Form
	{
	public:
		Setting(void)
		{
			InitializeComponent();
			//
			//TODO: aggiungere qui il codice del costruttore.
			//
		}

	protected:
		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		~Setting()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	protected:

	protected:





	private:
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Setting::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(33, 56);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(661, 270);
			this->label1->TabIndex = 0;
			this->label1->Text = L"...";
			this->label1->Click += gcnew System::EventHandler(this, &Setting::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Castellar", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(37, 22);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(14, 19);
			this->label2->TabIndex = 1;
			this->label2->Text = L".";
			// 
			// Setting
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::PeachPuff;
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(722, 350);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->MaximumSize = System::Drawing::Size(738, 389);
			this->MinimizeBox = false;
			this->MinimumSize = System::Drawing::Size(738, 389);
			this->Name = L"Setting";
			this->ShowInTaskbar = false;
			this->Text = L"Regole";
			this->Load += gcnew System::EventHandler(this, &Setting::Setting_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {

		//Start ^ startForm = gcnew Start();
		// this->Close();  oppure this->Hide();
		//startForm->Show();						// !!!!!!!!!!!!!!!!!!!!!!! passare con informazioni predefinite in variabili globali


	}
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void Setting_Load(System::Object^  sender, System::EventArgs^  e) {
		label2->Text = "Regole:";
		label1->Text = "La partita di scacchi si gioca tra due avversari che muovono\ni propri pezzi su una tavola quadrata detta �scacchiera�.\nIl giocatore che ha i pezzi di colore chiaro(Bianco) esegue la prima mossa; \nquindi i giocatori muovono alternativamente, con il giocatore che ha i pezzi\ndi colore scuro(Nero) che esegue la mossa successiva.\nL�obiettivo di ciascun giocatore � porre il Re avversario �sotto attacco� in\nmaniera tale che l�avversario non abbia pi� alcuna mossa legale.\nIl giocatore che raggiunge questo risultato � detto aver dato �scaccomatto� al\nRe avversario ed ha vinto la partita.\nNon � consentito lasciare il proprio Re sotto attacco, esporre il proprio Re\nall�attacco e nemmeno �catturare� il Re avversario.\nL�avversario il cui Re sia stato posto in scaccomatto ha perso la partita.";
	}
	};
}
