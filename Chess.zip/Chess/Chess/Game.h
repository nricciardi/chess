#pragma once
#include <ctime>
#include <stdlib.h>
#include "endGamePopUp.h"

#include <time.h>
#include <math.h>
#include <cmath>
#include <Windows.h>

///!!!!!!!!!!!!!                 inserire il caso 3 nel case

// Load(Application::StartupPath + "percorso") --> startup � la cartella del debug

namespace Chess {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Media;

	/// <summary>
	/// Riepilogo per Game
	/// </summary>
	public ref class Game : public System::Windows::Forms::Form
	{
	public:
		Game(int index, String^ giocatore1, String^ giocatore2, int elo)
		{
			InitializeComponent();
			S = new int*[8];					// matrice rappresentante la scacchiera logica
			mangiatiB = new int[6];				// array dei mangiati
			mangiatiN = new int[6];				// array dei mangiati

			for (int i = 0; i < 8; i++)
			{
				mangiatiB[i] = 0;
				mangiatiN[i] = 0;
			}

			for (int i = 0; i < 8; i++)
			{
				S[i] = new int[8];
			}

			//int index = 0;
			if (giocatore1 == "")
				giocatore1 = "Giocatore 1";
			if (giocatore2 == "")
				giocatore2 = "Giocatore 2";
			gioc1 = giocatore1;
			gioc2 = giocatore2;
			g1->Text = giocatore1;
			g2->Text = giocatore2;
			loadScacchiera(index);
			refreshScacchiera();

			indexGame = index;		// indice globale
			eloAi = elo;
			///VARIABILI PER ALGORITMO DI RICERCA MOSSA
			BestMove = new int[4];				// sequenza di 4 interi con le coordinate delle mosse migliore per AI
			Value = new int[20];
			Board = new int*[12];				// scacchiera logica
			for (int i = 0; i < 12; i++)
				Board[i] = new int[12];
				
			AttackedH = new int*[12];			// Scacchiera logica coi punti attaccatti dai pezzi umani
			for (int i = 0; i < 12; i++)
				AttackedH[i] = new int[12];			

			AttackedC = new int*[12];			// scacchiera logica coi punti attaccati dai pezzi AI
			for (int i = 0; i < 12; i++)
				AttackedC[i] = new int[12];


			NewGame();			// avvia default la scacchiera virtuale del computer
			///---------------------------------------

		}

		///---------------------------------------------------------------Funzioni
		
		void mainGame(int row, int col, PictureBox^ cas) 
		{		// funzione che viene richiamata ogni volta che viene cliccato una casella e gestisce ogni successiva azione

			//MessageBox::Show("Riga: " + row + "\tColonna:" + col + "\tValore Matrice:" + S[row][col] + "\tValori in memoria: row:" + indiceRowValorePezzoAttuale + " col:" + indiceColValorePezzoAttuale);		// per debug

			// MessageBox::Show(Application::StartupPath);					// per il debug

			resetColori();			// resetta i colori 

			if (turn) 
			{			// verifico se � il turno del nero (=false) o del bianco (=true)

				if (S[row][col] > 20 && S[row][col] < 100)
				{	// se � del bianco verifico che nella posizione selezionata ci sia una pedina del bianco (>20 e !=0 e <100 per evitare di selezione anche le caselle vuote)

					//... turno corretto, pedina del bianco

					resetScacchiera();
					resetColori();			// resetta i colori 

					indiceColValorePezzoAttuale = col;
					indiceRowValorePezzoAttuale = row;

					bluCasellaAttuale(cas);	// se il turno � corretto, la pedina anche, imposto lo sfondo blu alla picturebox

					mossePossibiliBianco(row, col);		// calcola le mosse possibili del pezzo (passato attraverso gli indici)
			


					// alla fine della funzione deve resettare tutti i colori e cambiare la var turn

					

				}
				

			}
			else 
			{		// � il turno del nero
				if (indexGame != 3 && !turn)		// non deve giocare l'AI per giocare il player
				{

					if (S[row][col] < 20 && S[row][col] != 0)
					{	// se � del nero verifico che nella posizione selezionata ci sia una pedina del nero (<20 e !=0)

						//... turno corretto, pedina del nero
						resetScacchiera();
						resetColori();			// resetta i colori

						indiceColValorePezzoAttuale = col;
						indiceRowValorePezzoAttuale = row;

						bluCasellaAttuale(cas);	// se il turno � corretto, la pedina anche, imposto lo sfondo blu alla picturebox

						mossePossibiliNero(row, col);
					


						// alla fine della funzione deve resettare tutti i colori e cambiare la var turn

						//turn = !turn;	// inverte il turno

					}
					
				}

			}

			

		
			if (S[row][col] == 100)			// controlla se si clicca una casella verde
			{
				
				S[row][col] = S[indiceRowValorePezzoAttuale][indiceColValorePezzoAttuale];		// muove le pedine
				S[indiceRowValorePezzoAttuale][indiceColValorePezzoAttuale] = 0;
				
				/// Passaggio della mossa effettuata all'AI
				

				if (indexGame == 3)				// solo se gioca contro AI
				{

					int x1 = 0;
					int y1 = 0;
					int x2 = 0;
					int y2 = 0;

					//Sleep(500);

					convertitoreIndici(indiceColValorePezzoAttuale, indiceRowValorePezzoAttuale, col, row, x1, y1, x2, y2);
					// x1 y1 x2 y2
					Start(x1, y1, x2, y2);

				}
					

				///--------------

				if (S[row][col] == 21)			// setta i pedoni a 22 o 2 dopo il primo spostamento			
					S[row][col] = 22;
				if (S[row][col] == 1)
					S[row][col] = 2;

				if (S[row][col] == 22 && row == 0)			// controllo per trasformare il pedone in regina
					S[row][col] = 26;
				if (S[row][col] == 2 && row == 7)
					S[row][col] = 6;
				// resettare anche la matrice
				resetScacchiera();
				
				refreshScacchiera();

				playMoveSound();

				resetColori();
				if (!turn)
					nTurni++;			// incrementa il turno
				turn = !turn;	// inverte il turno	

			}

			if (S[row][col] > 200)		// controlla se si clicca una casella rossa
			{

				switch (S[row][col] - 200)
				{
				case 1:
				{
					mangiatiN[0]++;

					break;
				}
				case 2:
				{
					mangiatiN[0]++;

					break;
				}
				case 3:
				{
					mangiatiN[1]++;

					break;
				}
				case 4:
				{
					mangiatiN[2]++;

					break;
				}
				case 5:
				{
					mangiatiN[3]++;

					break;
				}
				case 6:
				{
					mangiatiN[4]++;

					break;
				}
				case 10:
				{
					mangiatiN[5]++;

					break;
				}

				case 21:
				{
					mangiatiB[0]++;

					break;
				}
				case 22:
				{
					mangiatiB[0]++;

					break;
				}
				case 23:
				{
					mangiatiB[1]++;

					break;
				}
				case 24:
				{
					mangiatiB[2]++;

					break;
				}
				case 25:
				{
					mangiatiB[3]++;

					break;
				}
				case 26:
				{
					mangiatiB[4]++;

					break;
				}
				case 30:
				{
					mangiatiB[5]++;

					break;
				}

				default:
					break;
				}

				S[row][col] = S[indiceRowValorePezzoAttuale][indiceColValorePezzoAttuale];
				S[indiceRowValorePezzoAttuale][indiceColValorePezzoAttuale] = 0;

				/// Passaggio della mossa effettuata all'AI

				

				if (indexGame == 3)		// solo se si gioca contro AI
				{

					int x1 = 0;
					int y1 = 0;
					int x2 = 0;
					int y2 = 0;

					//Sleep(500);

					convertitoreIndici(indiceColValorePezzoAttuale, indiceRowValorePezzoAttuale, col, row, x1, y1, x2, y2);
					// x1 y1 x2 y2
					Start(x1, y1, x2, y2);

				}


				///--------------

				if (S[row][col] == 21)
					S[row][col] = 22;

				if (S[row][col] == 1)
					S[row][col] = 2;

				if (S[row][col] == 22 && row == 0)			// controllo per trasformare il pedone in regina
					S[row][col] = 26;
				if (S[row][col] == 2 && row == 7)
					S[row][col] = 6;

				// resettare anche la matrice
				resetScacchiera();
				playMoveSound();
				refreshScacchiera();
				resetColori();

				if (!turn)
					nTurni++;			// incrementa il turno

				turn = !turn;	// inverte il turno	

			}

			endGame();

			if(turn)
				LabelTurno->Text = "Turno " + nTurni + " giocatore BIANCO";	// Compare il turno nel bianco
			else
				LabelTurno->Text = "Turno " + nTurni + " giocatore NERO";	// Compare il turno nel nero

		}

		// a colonne, b righe
		void convertitoreIndici(int a1, int b1, int a2, int b2, int &a3, int &b3, int &a4, int &b4) 
		{
			a3 = a1 + 2;
			a4 = a2 + 2;
			
			b3 = 9 - b1;
			b4 = 9 - b2;
		}

		void convertitoreIndiciRitorno(int a1, int b1, int a2, int b2, int &a3, int &b3, int &a4, int &b4)
		{
			a3 = a1 - 2;
			a4 = a2 - 2;

			b3 = 9 - b1;
			b4 = 9 - b2;
		}


		void endGame()
		{
			if (mangiatiB[5] == 1 || mangiatiN[5] == 1)
			{
				c00->Enabled = false;
				c01->Enabled = false;
				c02->Enabled = false;
				c03->Enabled = false;
				c04->Enabled = false;
				c05->Enabled = false;
				c06->Enabled = false;
				c07->Enabled = false;
				c10->Enabled = false;
				c11->Enabled = false;
				c12->Enabled = false;
				c13->Enabled = false;
				c14->Enabled = false;
				c15->Enabled = false;
				c16->Enabled = false;
				c17->Enabled = false;
				c20->Enabled = false;
				c21->Enabled = false;
				c22->Enabled = false;
				c23->Enabled = false;
				c24->Enabled = false;
				c25->Enabled = false;
				c26->Enabled = false;
				c27->Enabled = false;
				c30->Enabled = false;
				c31->Enabled = false;
				c32->Enabled = false;
				c33->Enabled = false;
				c34->Enabled = false;
				c35->Enabled = false;
				c36->Enabled = false;
				c37->Enabled = false;
				c40->Enabled = false;
				c41->Enabled = false;
				c42->Enabled = false;
				c43->Enabled = false;
				c44->Enabled = false;
				c45->Enabled = false;
				c46->Enabled = false;
				c47->Enabled = false;
				c50->Enabled = false;
				c51->Enabled = false;
				c52->Enabled = false;
				c53->Enabled = false;
				c54->Enabled = false;
				c55->Enabled = false;
				c56->Enabled = false;
				c57->Enabled = false;
				c60->Enabled = false;
				c61->Enabled = false;
				c62->Enabled = false;
				c63->Enabled = false;
				c64->Enabled = false;
				c65->Enabled = false;
				c66->Enabled = false;
				c67->Enabled = false;
				c70->Enabled = false;
				c71->Enabled = false;
				c72->Enabled = false;
				c73->Enabled = false;
				c74->Enabled = false;
				c75->Enabled = false;
				c76->Enabled = false;
				c77->Enabled = false;

				LabelTurno->Text = "Scaccomatto!";

				if (mangiatiB[5]) 
				{
					endGamePopUp^ END = gcnew endGamePopUp(gioc1);
					END->ShowDialog();
				} 
				else
				{
					endGamePopUp^ END = gcnew endGamePopUp(gioc2);
					END->ShowDialog();

				}
					

					

			}
		}

		void loadScacchiera(int index) 
		{		// funzione che carica la scacchiera dato un indice per le varie versioni

			// Pedone nero:		1 (dopo primo tocco 2)
			// Torre nera:		3
			// Cavallo nero:	4
			// Alfiere nero:	5
			// Regina nera:		6
			// Re nero:			10

			// Pedone nero:		21 (dopo primo tocco 22)
			// Torre nera:		23
			// Cavallo nero:	24
			// Alfiere nero:	25
			// Regina nera:		26
			// Re nero:			30

			switch (index)
			{
			case 0: 
			{				// caso della scacchiera default

				for (int i = 0; i < 8; i++)
					for (int j = 0; j < 8; j++)
					{
						if (i == 1)
						{
							S[i][j] = 1;		// Pedone nero
						}
						else
						{
							if (i == 6)
							{
								S[i][j] = 21;		// Pedone bianco
							}
							else
								S[i][j] = 0;
						}
					}

				// torri
				S[0][0] = 3;
				S[0][7] = 3;
				S[7][0] = 23;
				S[7][7] = 23;

				// cavalli
				S[0][1] = 4;
				S[0][6] = 4;
				S[7][1] = 24;
				S[7][6] = 24;

				// alfieri
				S[0][2] = 5;
				S[0][5] = 5;
				S[7][2] = 25;
				S[7][5] = 25;

				// regine
				S[0][3] = 6;
				S[7][3] = 26;

				// re
				S[0][4] = 10;
				S[7][4] = 30;



				break;
			}
			case 1:			// BadCHESS
			{
				srand(time(0));

				for (int i = 0; i < 8; i++)
				{
					for (int j = 0; j < 8; j++)
					{
						S[i][j] = 0;
					}
				}

				for (int i = 0; i < 2; i++)
				{
					for (int j = 0; j < 8; j++)
					{
						S[i][j] = rand()%(6 - 1 + 1) + 1;
						if (S[i][j] == 2)
							S[i][j] = 1;
					}
				}

				for (int i = 6; i < 8; i++)
				{
					for (int j = 0; j < 8; j++)
					{
						S[i][j] = rand() % (26 - 21 + 1) + 21;
						if (S[i][j] == 22)
							S[i][j] = 21;
					}
				}

				S[0][4] = 10;
				S[7][4] = 30;

				break;
			}
			case 2:
			{
				for (int i = 0; i < 8; i++)
				{
					for (int j = 0; j < 8; j++)
					{
						S[i][j] = 0;
					}
				}

				for (int j = 0; j < 8; j++)
					S[1][j] = 1;

				// torri
				S[0][0] = 3;
				S[0][7] = 3;

				// cavalli
				S[0][1] = 4;
				S[0][6] = 4;

				// alfieri
				S[0][2] = 5;
				S[0][5] = 5;

				// regina
				S[0][3] = 6;

				// re
				S[0][4] = 10;

				for(int i = 5; i < 8; i++)
					for (int j = 0; j < 8; j++)
						S[i][j] = 21;

				S[4][4] = 21;
				S[4][3] = 21;
				break;
			}
			case 3:
			{

				for (int i = 0; i < 8; i++)
					for (int j = 0; j < 8; j++)
					{
						if (i == 1)
						{
							S[i][j] = 1;		// Pedone nero
						}
						else
						{
							if (i == 6)
							{
								S[i][j] = 21;		// Pedone bianco
							}
							else
								S[i][j] = 0;
						}
					}

				// torri
				S[0][0] = 3;
				S[0][7] = 3;
				S[7][0] = 23;
				S[7][7] = 23;

				// cavalli
				S[0][1] = 4;
				S[0][6] = 4;
				S[7][1] = 24;
				S[7][6] = 24;

				// alfieri
				S[0][2] = 5;
				S[0][5] = 5;
				S[7][2] = 25;
				S[7][5] = 25;

				// regine
				S[0][3] = 6;
				S[7][3] = 26;

				// re
				S[0][4] = 10;
				S[7][4] = 30;



				break;

			}


			}	// fine switch-case
		}// fine funzione

		void refreshScacchiera() {				// funzione per caricare le immagini a ogni riachiamo in base al valore

			setCaselleMosse();				// richiamo anche per far diventare verde e rosso

			// carica l'immagine nella casella indicata solo se � presente un pezzo
			if (returnImgValue(0, 0))
				c00->Load(returnImgValue(0, 0));
			if (returnImgValue(0, 1))
				c01->Load(returnImgValue(0, 1));
			if (returnImgValue(0, 2))
				c02->Load(returnImgValue(0, 2));
			if (returnImgValue(0, 3))
				c03->Load(returnImgValue(0, 3));
			if (returnImgValue(0, 4))
				c04->Load(returnImgValue(0, 4));
			if (returnImgValue(0, 5))
				c05->Load(returnImgValue(0, 5));
			if (returnImgValue(0, 6))
				c06->Load(returnImgValue(0, 6));
			if (returnImgValue(0, 7))
				c07->Load(returnImgValue(0, 7));
			if (returnImgValue(1, 0))
				c10->Load(returnImgValue(1, 0));
			if (returnImgValue(1, 1))
				c11->Load(returnImgValue(1, 1));
			if (returnImgValue(1, 2))
				c12->Load(returnImgValue(1, 2));
			if (returnImgValue(1, 3))
				c13->Load(returnImgValue(1, 3));
			if (returnImgValue(1, 4))
				c14->Load(returnImgValue(1, 4));
			if (returnImgValue(1, 5))
				c15->Load(returnImgValue(1, 5));
			if (returnImgValue(1, 6))
				c16->Load(returnImgValue(1, 6));
			if (returnImgValue(1, 7))
				c17->Load(returnImgValue(1, 7));
			if (returnImgValue(2, 0))
				c20->Load(returnImgValue(2, 0));
			if (returnImgValue(2, 1))
				c21->Load(returnImgValue(2, 1));
			if (returnImgValue(2, 2))
				c22->Load(returnImgValue(2, 2));
			if (returnImgValue(2, 3))
				c23->Load(returnImgValue(2, 3));
			if (returnImgValue(2, 4))
				c24->Load(returnImgValue(2, 4));
			if (returnImgValue(2, 5))
				c25->Load(returnImgValue(2, 5));
			if (returnImgValue(2, 6))
				c26->Load(returnImgValue(2, 6));
			if (returnImgValue(2, 7))
				c27->Load(returnImgValue(2, 7));
			if (returnImgValue(3, 0))
				c30->Load(returnImgValue(3, 0));
			if (returnImgValue(3, 1))
				c31->Load(returnImgValue(3, 1));
			if (returnImgValue(3, 2))
				c32->Load(returnImgValue(3, 2));
			if (returnImgValue(3, 3))
				c33->Load(returnImgValue(3, 3));
			if (returnImgValue(3, 4))
				c34->Load(returnImgValue(3, 4));
			if (returnImgValue(3, 5))
				c35->Load(returnImgValue(3, 5));
			if (returnImgValue(3, 6))
				c36->Load(returnImgValue(3, 6));
			if (returnImgValue(3, 7))
				c37->Load(returnImgValue(3, 7));
			if (returnImgValue(4, 0))
				c40->Load(returnImgValue(4, 0));
			if (returnImgValue(4, 1))
				c41->Load(returnImgValue(4, 1));
			if (returnImgValue(4, 2))
				c42->Load(returnImgValue(4, 2));
			if (returnImgValue(4, 3))
				c43->Load(returnImgValue(4, 3));
			if (returnImgValue(4, 4))
				c44->Load(returnImgValue(4, 4));
			if (returnImgValue(4, 5))
				c45->Load(returnImgValue(4, 5));
			if (returnImgValue(4, 6))
				c46->Load(returnImgValue(4, 6));
			if (returnImgValue(4, 7))
				c47->Load(returnImgValue(4, 7));
			if (returnImgValue(5, 0))
				c50->Load(returnImgValue(5, 0));
			if (returnImgValue(5, 1))
				c51->Load(returnImgValue(5, 1));
			if (returnImgValue(5, 2))
				c52->Load(returnImgValue(5, 2));
			if (returnImgValue(5, 3))
				c53->Load(returnImgValue(5, 3));
			if (returnImgValue(5, 4))
				c54->Load(returnImgValue(5, 4));
			if (returnImgValue(5, 5))
				c55->Load(returnImgValue(5, 5));
			if (returnImgValue(5, 6))
				c56->Load(returnImgValue(5, 6));
			if (returnImgValue(5, 7))
				c57->Load(returnImgValue(5, 7));
			if (returnImgValue(6, 0))
				c60->Load(returnImgValue(6, 0));
			if (returnImgValue(6, 1))
				c61->Load(returnImgValue(6, 1));
			if (returnImgValue(6, 2))
				c62->Load(returnImgValue(6, 2));
			if (returnImgValue(6, 3))
				c63->Load(returnImgValue(6, 3));
			if (returnImgValue(6, 4))
				c64->Load(returnImgValue(6, 4));
			if (returnImgValue(6, 5))
				c65->Load(returnImgValue(6, 5));
			if (returnImgValue(6, 6))
				c66->Load(returnImgValue(6, 6));
			if (returnImgValue(6, 7))
				c67->Load(returnImgValue(6, 7));
			if (returnImgValue(7, 0))
				c70->Load(returnImgValue(7, 0));
			if (returnImgValue(7, 1))
				c71->Load(returnImgValue(7, 1));
			if (returnImgValue(7, 2))
				c72->Load(returnImgValue(7, 2));
			if (returnImgValue(7, 3))
				c73->Load(returnImgValue(7, 3));
			if (returnImgValue(7, 4))
				c74->Load(returnImgValue(7, 4));
			if (returnImgValue(7, 5))
				c75->Load(returnImgValue(7, 5));
			if (returnImgValue(7, 6))
				c76->Load(returnImgValue(7, 6));
			if (returnImgValue(7, 7))
				c77->Load(returnImgValue(7, 7));

			label1->Text = System::Convert::ToString(mangiatiN[0]);
			label6->Text = System::Convert::ToString(mangiatiN[1]);
			label7->Text = System::Convert::ToString(mangiatiN[2]);
			label8->Text = System::Convert::ToString(mangiatiN[3]);
			label9->Text = System::Convert::ToString(mangiatiN[4]);

			label10->Text = System::Convert::ToString(mangiatiB[0]);
			label11->Text = System::Convert::ToString(mangiatiB[1]);
			label12->Text = System::Convert::ToString(mangiatiB[2]);
			label13->Text = System::Convert::ToString(mangiatiB[3]);
			label14->Text = System::Convert::ToString(mangiatiB[4]);

		}

		String^ returnImgValue(int row, int col) {				// sottofunzione di refreshScacchiera(), restituisce la stringa con il percorso delle immagini

			switch (S[row][col]) {

			// casi per immagini NERE

			case 1: {

				return Application::StartupPath + "\\..\\img\\" + "PedoneN.png";
				break;

			}

			case 2: {

				return Application::StartupPath + "\\..\\img\\" + "PedoneN.png";
				break;
			}

			case 3: {

				return Application::StartupPath + "\\..\\img\\" + "TorreN.png";
				break;
			}

			case 7: {

				return Application::StartupPath + "\\..\\img\\" + "TorreN.png";
				break;
			}

			case 4: {

				return Application::StartupPath + "\\..\\img\\" + "CavalloN.png";
				break;
			}

			case 5: {

				return Application::StartupPath + "\\..\\img\\" + "AlfiereN.png";
				break;
			}

			case 6: {

				return Application::StartupPath + "\\..\\img\\" + "ReginaN.png";
				break;
			}

			case 10: {

				return Application::StartupPath + "\\..\\img\\" + "ReN.png";
				break;
			}

			case 11: {

				return Application::StartupPath + "\\..\\img\\" + "ReN.png";
				break;
			}

			// casi per immagini BIANCHE

			case 21: {

				return Application::StartupPath + "\\..\\img\\" + "PedoneB.png";
				break;

			}

			case 22: {

				return Application::StartupPath + "\\..\\img\\" + "PedoneB.png";
				break;
			}

			case 23: {

				return Application::StartupPath + "\\..\\img\\" + "TorreB.png";
				break;
			}

			case 27: {

				return Application::StartupPath + "\\..\\img\\" + "TorreB.png";
				break;
			}

			case 24: {

				return Application::StartupPath + "\\..\\img\\" + "CavalloB.png";
				break;
			}

			case 25: {

				return Application::StartupPath + "\\..\\img\\" + "AlfiereB.png";
				break;
			}

			case 26: {

				return Application::StartupPath + "\\..\\img\\" + "ReginaB.png";
				break;
			}

			case 30: {

				return Application::StartupPath + "\\..\\img\\" + "ReB.png";
				break;
			}

			case 31: {

				return Application::StartupPath + "\\..\\img\\" + "ReB.png";
				break;
			}

			case 0: {							// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! trovare un immagine neutra

				return Application::StartupPath + "\\..\\img\\" + "CasellaVuota.png";
				break;
			}

			}

		}

		void bluCasellaAttuale(PictureBox^ cas) {		// funzione che cambia colore alla casella passata

			resetColori();	//resetto gli altri colori per non avere pi� pedine selezionate
			cas->BackColor = CasBlu;		// colore della casella del pezzo
			
		}

		void resetColori() {	// funzione di reset colori per il successivo turno

			// lista dove si setta a trasparente lo sfondo di tutte le picturebox
			
			if (true) {								// DEBUG: abilita o disabilita il reset delle caselle

				// 0x
				c00->BackColor = Trasparente;
				c01->BackColor = Trasparente;
				c02->BackColor = Trasparente;
				c03->BackColor = Trasparente;
				c04->BackColor = Trasparente;
				c05->BackColor = Trasparente;
				c06->BackColor = Trasparente;
				c07->BackColor = Trasparente;

				// 1x
				c10->BackColor = Trasparente;
				c11->BackColor = Trasparente;
				c12->BackColor = Trasparente;
				c13->BackColor = Trasparente;
				c14->BackColor = Trasparente;
				c15->BackColor = Trasparente;
				c16->BackColor = Trasparente;
				c17->BackColor = Trasparente;

				// 2x
				c20->BackColor = Trasparente;
				c21->BackColor = Trasparente;
				c22->BackColor = Trasparente;
				c23->BackColor = Trasparente;
				c24->BackColor = Trasparente;
				c25->BackColor = Trasparente;
				c26->BackColor = Trasparente;
				c27->BackColor = Trasparente;

				// 3x
				c30->BackColor = Trasparente;
				c31->BackColor = Trasparente;
				c32->BackColor = Trasparente;
				c33->BackColor = Trasparente;
				c34->BackColor = Trasparente;
				c35->BackColor = Trasparente;
				c36->BackColor = Trasparente;
				c37->BackColor = Trasparente;

				// 4x
				c40->BackColor = Trasparente;
				c41->BackColor = Trasparente;
				c42->BackColor = Trasparente;
				c43->BackColor = Trasparente;
				c44->BackColor = Trasparente;
				c45->BackColor = Trasparente;
				c46->BackColor = Trasparente;
				c47->BackColor = Trasparente;

				// 5x
				c50->BackColor = Trasparente;
				c51->BackColor = Trasparente;
				c52->BackColor = Trasparente;
				c53->BackColor = Trasparente;
				c54->BackColor = Trasparente;
				c55->BackColor = Trasparente;
				c56->BackColor = Trasparente;
				c57->BackColor = Trasparente;

				// 6x
				c60->BackColor = Trasparente;
				c61->BackColor = Trasparente;
				c62->BackColor = Trasparente;
				c63->BackColor = Trasparente;
				c64->BackColor = Trasparente;
				c65->BackColor = Trasparente;
				c66->BackColor = Trasparente;
				c67->BackColor = Trasparente;

				// 7x
				c70->BackColor = Trasparente;
				c71->BackColor = Trasparente;
				c72->BackColor = Trasparente;
				c73->BackColor = Trasparente;
				c74->BackColor = Trasparente;
				c75->BackColor = Trasparente;
				c76->BackColor = Trasparente;
				c77->BackColor = Trasparente;


			}

		}

		

		void resetScacchiera() {		// funzione per resettare la scacchiera

			for (int i = 0; i < 8; i++)
				for (int j = 0; j < 8; j++) {
					if (S[i][j] == 100)				// se una casella ha un valore nominale di 100, significa che va pulita con lo 0 (perche non erano presenti altri pezzi)
						S[i][j] = 0;

					if (S[i][j] > 200)				// se una casella ha un valore nominale >200, significa che va pulita rimettendo il valore precendente (perche erano presenti altri pezzi)
						S[i][j] -= 200;

				}

			for (int i = 0; i < 8; i++)			// secondo controllo della matrice
				for (int j = 0; j < 8; j++)
					if (S[i][j] > 200)
						S[i][j] = S[i][j] - 200;
		}

		void mossePossibiliBianco(int row, int col) {	// funzione che calcola tutte le mosse possibili del bianco con uno switch-case


			switch (S[row][col])
			{

			case 21: {	// Caso del pedone in posizione iniziale

				// imposta le mosse con un +100 se non ci sono pezzi nemici
				
				if (S[row - 1][col - 1] > 0 && S[row - 1][col - 1] < 20)			// controllo per mangiare
				{
					S[row - 1][col - 1] += 200;
				}

				if (S[row - 1][col + 1] > 0 && S[row - 1][col + 1] < 20)			// controllo per mangiare
				{
					S[row - 1][col + 1] += 200;
				}

				if (S[row - 1][col] == 0)				// Controllo per le caselle di spostamento (verdi)
				{
					S[row - 1][col] = 100;
					if (S[row - 2][col] == 0)				// Controllo per le caselle di spostamento (verdi)
						S[row - 2][col] = 100;
				}
				
				break;

			}

			case 22:		// Caso del pedone non in posizione iniziale
			{	
				if (S[row - 1][col - 1] > 0 && S[row - 1][col - 1] < 20)			// controllo per mangiare
				{
					S[row - 1][col - 1] += 200;
				}

				if (S[row - 1][col + 1] > 0 && S[row - 1][col + 1] < 20)			// controllo per mangiare
				{
					S[row - 1][col + 1] += 200;
				}

				if (S[row - 1][col] == 0)				// Controllo per le caselle di spostamento (verdi)
				{
					S[row - 1][col] = 100;
				}

				break;
			}

			case 23:		// Caso della torre
			{
				// Righe
				for (int i = row - 1; i >= 0; i--)
				{
					if (S[i][col] > 0 && S[i][col] < 20)			// se � presente un pezzo dell'avversario...
					{
						S[i][col] += 200;							// la casella diventa rossa per indicare che la torre pu� mangiarlo
						break;
					}
					else
					{
						if(S[i][col] == 0)
							S[i][col] = 100;							// altrimenti la casella si illumina per indicare il possibile spostamento
						else
							break;
					}
				}

				for (int i = row + 1; i < 8; i++)
				{
					if (S[i][col] > 0 && S[i][col] < 20)
					{
						S[i][col] += 200;
						break;
					}
					else
					{
						if (S[i][col] == 0)
							S[i][col] = 100;							// altrimenti la casella si illumina per indicare il possibile spostamento
						else
							break;
					}
				}
			
				// Colonne
				for (int i = col - 1; i >= 0; i--)
				{
					if (S[row][i] > 0 && S[row][i] < 20)			// se � presente un pezzo dell'avversario...
					{
						S[row][i] += 200;							// la casella diventa rossa per indicare che la torre pu� mangiarlo
						break;
					}
					else
					{
						if (S[row][i] == 0)
							S[row][i] = 100;							// altrimenti la casella si illumina per indicare il possibile spostamento
						else
							break;
					}
				}

				for (int i = col + 1; i < 8; i++)
				{
					if (S[row][i] > 0 && S[row][i] < 20)
					{
						S[row][i] += 200;
						break;
					}
					else
					{
						if (S[row][i] == 0)
							S[row][i] = 100;							
						else
							break;
					}
				}

				break;
			}
			
			case 24:		// Caso del cavallo
			{
			//**********************************************************************************
				if (row + 2 < 8 && col + 1 < 8)
				{
					if (S[row + 2][col + 1] > 0 && S[row + 2][col + 1] < 20)
						S[row + 2][col + 1] += 200;
					else
					{
						if (S[row + 2][col + 1] == 0)
							S[row + 2][col + 1] = 100;
					}
				}

			//**********************************************************************************
				if (row + 2 < 8 && col - 1 >= 0)
				{
					if (S[row + 2][col - 1] > 0 && S[row + 2][col - 1] < 20)
						S[row + 2][col - 1] += 200;
					else
					{
						if (S[row + 2][col - 1] == 0)
							S[row + 2][col - 1] = 100;
					}
				}

			//**********************************************************************************
				if (row + 1 < 8 && col - 2 >= 0)
				{
					if (S[row + 1][col - 2] > 0 && S[row + 1][col - 2] < 20)
						S[row + 1][col - 2] += 200;
					else
					{
						if (S[row + 1][col - 2] == 0)
							S[row + 1][col - 2] = 100;
					}
				}

			//**********************************************************************************
				if (row + 1 < 8 && col + 2 < 8)
				{
					if (S[row + 1][col + 2] > 0 && S[row + 1][col + 2] < 20)
						S[row + 1][col + 2] += 200;
					else
					{
						if (S[row + 1][col + 2] == 0)
							S[row + 1][col + 2] = 100;
					}
				}

			//**********************************************************************************
				if (row - 1 >= 0 && col + 2 < 8)
				{
					if (S[row - 1][col + 2] > 0 && S[row - 1][col + 2] < 20)
						S[row - 1][col + 2] += 200;
					else
					{
						if (S[row - 1][col + 2] == 0)
							S[row - 1][col + 2] = 100;
					}
				}

			//**********************************************************************************
				if (row - 2 >= 0 && col - 1 >= 0)
				{
					if (S[row - 2][col - 1] > 0 && S[row - 2][col - 1] < 20)
						S[row - 2][col - 1] += 200;
					else
					{
						if (S[row - 2][col - 1] == 0)
							S[row - 2][col - 1] = 100;
					}
				}

			//**********************************************************************************
				if (row - 2 >= 0 && col + 1 < 8)
				{
					if (S[row - 2][col + 1] > 0 && S[row - 2][col + 1] < 20)
						S[row - 2][col + 1] += 200;
					else
					{
						if (S[row - 2][col + 1] == 0)
							S[row - 2][col + 1] = 100;
					}
				}

			//**********************************************************************************
				if (row - 1 >= 0 && col - 2 >= 0)
				{
					if (S[row - 1][col - 2] > 0 && S[row - 1][col - 2] < 20)
						S[row - 1][col - 2] += 200;
					else
					{
						if (S[row - 1][col - 2] == 0)
							S[row - 1][col - 2] = 100;
					}
				}

				break;
			}

			case 25:		// Caso dell'alfiere
			{
				for(int i = row - 1, j = col - 1; i >= 0 && j >= 0; i--, j--)
				{
					if (S[i][j] > 0 && S[i][j] < 20)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				for (int i = row + 1, j = col + 1; i < 8 && j < 8; i++, j++)
				{
					if (S[i][j] > 0 && S[i][j] < 20)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				for (int i = row - 1, j = col + 1; i >= 0 && j < 8; i--, j++)
				{
					if (S[i][j] > 0 && S[i][j] < 20)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				for (int i = row + 1, j = col - 1; i < 8 && j >= 0; i++, j--)
				{
					if (S[i][j] > 0 && S[i][j] < 20)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				break;
			}

			case 26:			// Caso della regina
			{
			// Istruzioni torre
				// Righe
				for (int i = row - 1; i >= 0; i--)
				{
					if (S[i][col] > 0 && S[i][col] < 20)			// se � presente un pezzo dell'avversario...
					{
						S[i][col] += 200;							// la casella diventa rossa per indicare che la torre pu� mangiarlo
						break;
					}
					else
					{
						if (S[i][col] == 0)
							S[i][col] = 100;							// altrimenti la casella si illumina per indicare il possibile spostamento
						else
							break;
					}
				}

				for (int i = row + 1; i < 8; i++)
				{
					if (S[i][col] > 0 && S[i][col] < 20)
					{
						S[i][col] += 200;
						break;
					}
					else
					{
						if (S[i][col] == 0)
							S[i][col] = 100;							// altrimenti la casella si illumina per indicare il possibile spostamento
						else
							break;
					}
				}

				// Colonne
				for (int i = col - 1; i >= 0; i--)
				{
					if (S[row][i] > 0 && S[row][i] < 20)			// se � presente un pezzo dell'avversario...
					{
						S[row][i] += 200;							// la casella diventa rossa per indicare che la torre pu� mangiarlo
						break;
					}
					else
					{
						if (S[row][i] == 0)
							S[row][i] = 100;							// altrimenti la casella si illumina per indicare il possibile spostamento
						else
							break;
					}
				}

				for (int i = col + 1; i < 8; i++)
				{
					if (S[row][i] > 0 && S[row][i] < 20)
					{
						S[row][i] += 200;
						break;
					}
					else
					{
						if (S[row][i] == 0)
							S[row][i] = 100;
						else
							break;
					}
				}


			// Istruzioni alfiere
				for (int i = row - 1, j = col - 1; i >= 0 && j >= 0; i--, j--)
				{
					if (S[i][j] > 0 && S[i][j] < 20)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				for (int i = row + 1, j = col + 1; i < 8 && j < 8; i++, j++)
				{
					if (S[i][j] > 0 && S[i][j] < 20)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				for (int i = row - 1, j = col + 1; i >= 0 && j < 8; i--, j++)
				{
					if (S[i][j] > 0 && S[i][j] < 20)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				for (int i = row + 1, j = col - 1; i < 8 && j >= 0; i++, j--)
				{
					if (S[i][j] > 0 && S[i][j] < 20)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				break;
			}

			case 30:		// Caso del re
			{	
				if (row - 1 < 0)			
				{
					if (col - 1 < 0)		// OX
					{						// XX
						if (S[row + 1][col + 1] > 0 && S[row + 1][col + 1] < 20)
						{
							S[row + 1][col + 1] += 200;
							break;
						}
						else
						{
							if (S[row + 1][col + 1] == 0)
								S[row + 1][col + 1] = 100;
						}

						if (S[row + 1][col] > 0 && S[row + 1][col] < 20)	
						{
							S[row + 1][col] += 200;
							break;
						}
						else
						{
							if (S[row + 1][col] == 0)
								S[row + 1][col] = 100;
						}

						if (S[row][col + 1] > 0 && S[row][col + 1] < 20)
						{
							S[row][col + 1] += 200;
							break;
						}
						else
						{
							if (S[row][col + 1] == 0)
								S[row][col + 1] = 100;
						}
					}
					else
					{
						if (col + 1 >= 8)			// XO
						{							// XX
							if (S[row][col - 1] > 0 && S[row][col - 1] < 20)
							{
								S[row][col - 1] += 200;
								break;
							}
							else
							{
								if (S[row][col - 1] == 0)
									S[row][col - 1] = 100;
							}

							if (S[row + 1][col] > 0 && S[row + 1][col] < 20)
							{
								S[row + 1][col] += 200;
								break;
							}
							else
							{
								if (S[row + 1][col] == 0)
									S[row + 1][col] = 100;
							}

							if (S[row + 1][col - 1] > 0 && S[row + 1][col - 1] < 20)
							{
								S[row + 1][col - 1] += 200;
								break;
							}
							else
							{
								if (S[row + 1][col - 1] == 0)
									S[row + 1][col - 1] = 100;
							}
						}
						else		// XOX
						{			// XXX
							if (S[row][col - 1] > 0 && S[row][col - 1] < 20)
							{
								S[row][col - 1] += 200;
								break;
							}
							else
							{
								if (S[row][col - 1] == 0)
									S[row][col - 1] = 100;
							}

							if (S[row][col + 1] > 0 && S[row][col + 1] < 20)
							{
								S[row][col + 1] += 200;
								break;
							}
							else
							{
								if (S[row][col + 1] == 0)
									S[row][col + 1] = 100;
							}

							if (S[row + 1][col + 1] > 0 && S[row + 1][col + 1] < 20)
							{
								S[row + 1][col + 1] += 200;
								break;
							}
							else
							{
								if (S[row + 1][col + 1] == 0)
									S[row + 1][col + 1] = 100;
							}

							if (S[row + 1][col] > 0 && S[row + 1][col] < 20)
							{
								S[row + 1][col] += 200;
								break;
							}
							else
							{
								if (S[row + 1][col] == 0)
									S[row + 1][col] = 100;
							}

							if (S[row + 1][col - 1] > 0 && S[row + 1][col - 1] < 20)
							{
								S[row + 1][col - 1] += 200;
								break;
							}
							else
							{
								if (S[row + 1][col - 1] == 0)
									S[row + 1][col - 1] = 100;
							}
						}
					}
				}
				else
				{
					if (row + 1 >= 8)
					{
						if (col + 1 >= 8)		// XX
						{						// XO
							if (S[row - 1][col - 1] > 0 && S[row - 1][col - 1] < 20)
							{
								S[row - 1][col - 1] += 200;
								break;
							}
							else
							{
								if (S[row - 1][col - 1] == 0)
									S[row - 1][col - 1] = 100;
							}

							if (S[row - 1][col] > 0 && S[row - 1][col] < 20)
							{
								S[row - 1][col] += 200;
								break;
							}
							else
							{
								if (S[row - 1][col] == 0)
									S[row - 1][col] = 100;
							}

							if (S[row][col - 1] > 0 && S[row][col - 1] < 20)
							{
								S[row][col - 1] += 200;
								break;
							}
							else
							{
								if (S[row][col - 1] == 0)
									S[row][col - 1] = 100;
							}
						}
						else
						{
							if (col - 1 < 0)		// XX
							{						// OX
								if (S[row][col + 1] > 0 && S[row][col + 1] < 20)
								{
									S[row][col + 1] += 200;
									break;
								}
								else
								{
									if (S[row][col + 1] == 0)
										S[row][col + 1] = 100;
								}
								
								if (S[row - 1][col + 1] > 0 && S[row - 1][col + 1] < 20)
								{
									S[row - 1][col + 1] += 200;
									break;
								}
								else
								{
									if (S[row - 1][col + 1] == 0)
										S[row - 1][col + 1] = 100;
								}

								if (S[row - 1][col] > 0 && S[row - 1][col] < 20)
								{
									S[row - 1][col] += 200;
									break;
								}
								else
								{
									if (S[row - 1][col] == 0)
										S[row - 1][col] = 100;
								}
							}
							else		// XXX
							{			// XOX
								if (S[row - 1][col - 1] > 0 && S[row - 1][col - 1] < 20)
								{
									S[row - 1][col - 1] += 200;
									break;
								}
								else
								{
									if (S[row - 1][col - 1] == 0)
										S[row - 1][col - 1] = 100;
								}

								if (S[row - 1][col] > 0 && S[row - 1][col] < 20)
								{
									S[row - 1][col] += 200;
									break;
								}
								else
								{
									if (S[row - 1][col] == 0)
										S[row - 1][col] = 100;
								}

								if (S[row - 1][col + 1] > 0 && S[row - 1][col + 1] < 20)
								{
									S[row - 1][col + 1] += 200;
									break;
								}
								else
								{
									if (S[row - 1][col + 1] == 0)
										S[row - 1][col + 1] = 100;
								}

								if (S[row][col - 1] > 0 && S[row][col - 1] < 20)
								{
									S[row][col - 1] += 200;
									break;
								}
								else
								{
									if (S[row][col - 1] == 0)
										S[row][col - 1] = 100;
								}

								if (S[row][col + 1] > 0 && S[row][col + 1] < 20)
								{
									S[row][col + 1] += 200;
									break;
								}
								else
								{
									if (S[row][col + 1] == 0)
										S[row][col + 1] = 100;
								}

							}
						}
					}
					else
					{
						if (S[row - 1][col + 1] > 0 && S[row - 1][col + 1] < 20)
						{
							S[row - 1][col + 1] += 200;
							break;
						}
						else
						{
							if (S[row - 1][col + 1] == 0)
								S[row - 1][col + 1] = 100;
						}

						if (S[row - 1][col] > 0 && S[row - 1][col] < 20)
						{
							S[row - 1][col] += 200;
							break;
						}
						else
						{
							if (S[row - 1][col] == 0)
								S[row - 1][col] = 100;
						}

						if (S[row - 1][col - 1] > 0 && S[row - 1][col - 1] < 20)
						{
							S[row - 1][col - 1] += 200;
							break;
						}
						else
						{
							if (S[row - 1][col - 1] == 0)
								S[row - 1][col - 1] = 100;
						}

						if (S[row][col + 1] > 0 && S[row][col + 1] < 20)
						{
							S[row][col + 1] += 200;
							break;
						}
						else
						{
							if (S[row][col + 1] == 0)
								S[row][col + 1] = 100;
						}

						if (S[row][col - 1] > 0 && S[row][col - 1] < 20)
						{
							S[row][col - 1] += 200;
							break;
						}
						else
						{
							if (S[row][col - 1] == 0)
								S[row][col - 1] = 100;
						}

						if (S[row + 1][col - 1] > 0 && S[row + 1][col - 1] < 20)
						{
							S[row + 1][col - 1] += 200;
							break;
						}
						else
						{
							if (S[row + 1][col - 1] == 0)
								S[row + 1][col - 1] = 100;
						}

						if (S[row + 1][col] > 0 && S[row + 1][col] < 20)
						{
							S[row + 1][col] += 200;
							break;
						}
						else
						{
							if (S[row + 1][col] == 0)
								S[row + 1][col] = 100;
						}

						if (S[row + 1][col + 1] > 0 && S[row + 1][col + 1] < 20)
						{
							S[row + 1][col + 1] += 200;
							break;
						}
						else
						{
							if (S[row + 1][col + 1] == 0)
								S[row + 1][col + 1] = 100;
						}
					}
				}


				break;

			}

			default:
				break;
			}

			refreshScacchiera();


		}

		void mossePossibiliNero(int row, int col) {	// funzione che calcola tutte le mosse possibili del nero con uno switch-case

			switch (S[row][col])
			{
			case 1: {	// Caso del pedone in posizione iniziale

				//if(!(S[row + 1][col]))	// se la casella di arrivo � diversa da 0 (c'� una pedina) verifico se � presente un pezzo amico o nemico
				// Mosse di movimento pedone:
				// imposta le mosse con un +100 se non ci sono pezzi nemici
				if (S[row + 1][col] == 0)			// Verifica che la casella successiva sia libera
					S[row + 1][col] = 100;

				if (S[row + 2][col] == 0)
					S[row + 2][col] = 100;

				if (S[row + 1][col - 1] > 20)		// Verifica se il pedone pu� mangiare
					S[row + 1][col - 1] += 200;

				if (S[row + 1][col + 1] > 20)
					S[row + 1][col + 1] += 200;
				//... mosse per mangiare

			}

			case 2: {	// Caso del pedone non in posizione iniziale

				//if(!(S[row + 1][col]))	// se la casella di arrivo � diversa da 0 (c'� una pedina) verifico se � presente un pezzo amico o nemico
				// Mosse di movimento pedone:
				// imposta le mosse con un +100 se non ci sono pezzi nemici

				if ((row + 1) <= 7) {		// if per la condizione di uscita dalla scacchiera

					if (S[row + 1][col] == 0)			// Verifica che la casella successiva sia libera
						S[row + 1][col] = 100;

					if ((col - 1) >= 0)						// if per la condizione di uscita dalla scacchiera 
						if (S[row + 1][col - 1] > 20)		// Verifica se il pedone pu� mangiare
							S[row + 1][col - 1] += 200;

					if ((col + 1) <= 7)						// if per la condizione di uscita dalla scacchiera
						if (S[row + 1][col + 1] > 20)
							S[row + 1][col + 1] += 200;

				}

				break;

			}
			case 3:		// Caso della torre
			{
				// Righe
				for (int i = row - 1; i >= 0; i--)
				{
					if (S[i][col] > 20 && S[i][col] < 100)			// se � presente un pezzo dell'avversario...
					{
						S[i][col] += 200;							// la casella diventa rossa per indicare che la torre pu� mangiarlo
						break;
					}
					else
					{
						if (S[i][col] == 0)
							S[i][col] = 100;							// altrimenti la casella si illumina per indicare il possibile spostamento
						else
							break;
					}
				}

				for (int i = row + 1; i < 8; i++)
				{
					if (S[i][col] > 20 && S[i][col] < 100)
					{
						S[i][col] += 200;
						break;
					}
					else
					{
						if (S[i][col] == 0)
							S[i][col] = 100;							// altrimenti la casella si illumina per indicare il possibile spostamento
						else
							break;
					}
				}

				// Colonne
				for (int i = col - 1; i >= 0; i--)
				{
					if (S[row][i] > 20 && S[row][i] < 100)			// se � presente un pezzo dell'avversario...
					{
						S[row][i] += 200;							// la casella diventa rossa per indicare che la torre pu� mangiarlo
						break;
					}
					else
					{
						if (S[row][i] == 0)
							S[row][i] = 100;							// altrimenti la casella si illumina per indicare il possibile spostamento
						else
							break;
					}
				}

				for (int i = col + 1; i < 8; i++)
				{
					if (S[row][i] > 20 && S[row][i] < 100)
					{
						S[row][i] += 200;
						break;
					}
					else
					{
						if (S[row][i] == 0)
							S[row][i] = 100;
						else
							break;
					}
				}

				break;
			}

			case 4:		// Caso del cavallo
			{
				//**********************************************************************************
				if (row + 2 < 8 && col + 1 < 8)
				{
					if (S[row + 2][col + 1] > 20 && S[row + 2][col + 1] < 100)
						S[row + 2][col + 1] += 200;
					else
					{
						if (S[row + 2][col + 1] == 0)
							S[row + 2][col + 1] = 100;
					}
				}

				//**********************************************************************************
				if (row + 2 < 8 && col - 1 >= 0)
				{
					if (S[row + 2][col - 1] > 20 && S[row + 2][col - 1] < 100)
						S[row + 2][col - 1] += 200;
					else
					{
						if (S[row + 2][col - 1] == 0)
							S[row + 2][col - 1] = 100;
					}
				}

				//**********************************************************************************
				if (row + 1 < 8 && col - 2 >= 0)
				{
					if (S[row + 1][col - 2] > 20 && S[row + 1][col - 2] < 100)
						S[row + 1][col - 2] += 200;
					else
					{
						if (S[row + 1][col - 2] == 0)
							S[row + 1][col - 2] = 100;
					}
				}

				//**********************************************************************************
				if (row + 1 < 8 && col + 2 < 8)
				{
					if (S[row + 1][col + 2] > 20 && S[row + 1][col + 2] < 100)
						S[row + 1][col + 2] += 200;
					else
					{
						if (S[row + 1][col + 2] == 0)
							S[row + 1][col + 2] = 100;
					}
				}

				//**********************************************************************************
				if (row - 1 >= 0 && col + 2 < 8)
				{
					if (S[row - 1][col + 2] > 20 && S[row - 1][col + 2] < 100)
						S[row - 1][col + 2] += 200;
					else
					{
						if (S[row - 1][col + 2] == 0)
							S[row - 1][col + 2] = 100;
					}
				}

				//**********************************************************************************
				if (row - 2 >= 0 && col - 1 >= 0)
				{
					if (S[row - 2][col - 1] > 20 && S[row - 2][col - 1] < 100)
						S[row - 2][col - 1] += 200;
					else
					{
						if (S[row - 2][col - 1] == 0)
							S[row - 2][col - 1] = 100;
					}
				}

				//**********************************************************************************
				if (row - 2 >= 0 && col + 1 < 8)
				{
					if (S[row - 2][col + 1] > 20 && S[row - 2][col + 1] < 100)
						S[row - 2][col + 1] += 200;
					else
					{
						if (S[row - 2][col + 1] == 0)
							S[row - 2][col + 1] = 100;
					}
				}

				//**********************************************************************************
				if (row - 1 >= 0 && col - 2 >= 0)
				{
					if (S[row - 1][col - 2] > 20 && S[row - 1][col - 2] < 100)
						S[row - 1][col - 2] += 200;
					else
					{
						if (S[row - 1][col - 2] == 0)
							S[row - 1][col - 2] = 100;
					}
				}

				break;
			}

			case 5:		// Caso dell'alfiere
			{
				for (int i = row - 1, j = col - 1; i >= 0 && j >= 0; i--, j--)
				{
					if (S[i][j] > 20 && S[i][j] < 100)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				for (int i = row + 1, j = col + 1; i < 8 && j < 8; i++, j++)
				{
					if (S[i][j] > 20 && S[i][j] < 100)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				for (int i = row - 1, j = col + 1; i >= 0 && j < 8; i--, j++)
				{
					if (S[i][j] > 20 && S[i][j] < 100)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				for (int i = row + 1, j = col - 1; i < 8 && j >= 0; i++, j--)
				{
					if (S[i][j] > 20 && S[i][j] < 100)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				break;
			}

			case 6:			// Caso della regina
			{
				// Istruzioni torre
					// Righe
				for (int i = row - 1; i >= 0; i--)
				{
					if (S[i][col] > 20 && S[i][col] < 100)			// se � presente un pezzo dell'avversario...
					{
						S[i][col] += 200;							// la casella diventa rossa per indicare che la torre pu� mangiarlo
						break;
					}
					else
					{
						if (S[i][col] == 0)
							S[i][col] = 100;							// altrimenti la casella si illumina per indicare il possibile spostamento
						else
							break;
					}
				}

				for (int i = row + 1; i < 8; i++)
				{
					if (S[i][col] > 20 && S[i][col] < 100)
					{
						S[i][col] += 200;
						break;
					}
					else
					{
						if (S[i][col] == 0)
							S[i][col] = 100;							// altrimenti la casella si illumina per indicare il possibile spostamento
						else
							break;
					}
				}

				// Colonne
				for (int i = col - 1; i >= 0; i--)
				{
					if (S[row][i] > 20 && S[row][i] < 100)			// se � presente un pezzo dell'avversario...
					{
						S[row][i] += 200;							// la casella diventa rossa per indicare che la torre pu� mangiarlo
						break;
					}
					else
					{
						if (S[row][i] == 0)
							S[row][i] = 100;							// altrimenti la casella si illumina per indicare il possibile spostamento
						else
							break;
					}
				}

				for (int i = col + 1; i < 8; i++)
				{
					if (S[row][i] > 20 && S[row][i] < 100)
					{
						S[row][i] += 200;
						break;
					}
					else
					{
						if (S[row][i] == 0)
							S[row][i] = 100;
						else
							break;
					}
				}


				// Istruzioni alfiere
				for (int i = row - 1, j = col - 1; i >= 0 && j >= 0; i--, j--)
				{
					if (S[i][j] > 20 && S[i][j] < 100)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				for (int i = row + 1, j = col + 1; i < 8 && j < 8; i++, j++)
				{
					if (S[i][j] > 20 && S[i][j] < 100)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				for (int i = row - 1, j = col + 1; i >= 0 && j < 8; i--, j++)
				{
					if (S[i][j] > 20 && S[i][j] < 100)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				for (int i = row + 1, j = col - 1; i < 8 && j >= 0; i++, j--)
				{
					if (S[i][j] > 20 && S[i][j] < 100)
					{
						S[i][j] += 200;
						break;
					}
					else
					{
						if (S[i][j] == 0)
							S[i][j] = 100;
						else
							break;
					}
				}

				break;
			}

			case 10:		// Caso del re
			{

				if (row - 1 < 0)
				{
					if (col - 1 < 0)		// OX
					{						// XX
						if (S[row + 1][col + 1] > 20 && S[row + 1][col + 1] < 100)
						{
							S[row + 1][col + 1] += 200;
							break;
						}
						else
						{
							if (S[row + 1][col + 1] == 0)
								S[row + 1][col + 1] = 100;
						}

						if (S[row + 1][col] > 20 && S[row + 1][col] < 100)
						{
							S[row + 1][col] += 200;
							break;
						}
						else
						{
							if (S[row + 1][col] == 0)
								S[row + 1][col] = 100;
						}

						if (S[row][col + 1] > 20 && S[row][col + 1] < 100)
						{
							S[row][col + 1] += 200;
							break;
						}
						else
						{
							if (S[row][col + 1] == 0)
								S[row][col + 1] = 100;
						}
					}
					else
					{
						if (col + 1 >= 8)			// XO
						{							// XX
							if (S[row][col - 1] > 20 && S[row][col - 1] < 100)
							{
								S[row][col - 1] += 200;
								break;
							}
							else
							{
								if (S[row][col - 1] == 0)
									S[row][col - 1] = 100;
							}

							if (S[row + 1][col] > 20 && S[row + 1][col] < 100)
							{
								S[row + 1][col] += 200;
								break;
							}
							else
							{
								if (S[row + 1][col] == 0)
									S[row + 1][col] = 100;
							}

							if (S[row + 1][col - 1] > 20 && S[row + 1][col - 1] < 100)
							{
								S[row + 1][col - 1] += 200;
								break;
							}
							else
							{
								if (S[row + 1][col - 1] == 0)
									S[row + 1][col - 1] = 100;
							}
						}
						else		// XOX
						{			// XXX
							if (S[row][col - 1] > 20 && S[row][col - 1] < 100)
							{
								S[row][col - 1] += 200;
								break;
							}
							else
							{
								if (S[row][col - 1] == 0)
									S[row][col - 1] = 100;
							}

							if (S[row][col + 1] > 20 && S[row][col + 1] < 100)
							{
								S[row][col + 1] += 200;
								break;
							}
							else
							{
								if (S[row][col + 1] == 0)
									S[row][col + 1] = 100;
							}

							if (S[row + 1][col + 1] > 20 && S[row + 1][col + 1] < 100)
							{
								S[row + 1][col + 1] += 200;
								break;
							}
							else
							{
								if (S[row + 1][col + 1] == 0)
									S[row + 1][col + 1] = 100;
							}

							if (S[row + 1][col] > 20 && S[row + 1][col] < 100)
							{
								S[row + 1][col] += 200;
								break;
							}
							else
							{
								if (S[row + 1][col] == 0)
									S[row + 1][col] = 100;
							}

							if (S[row + 1][col - 1] > 20 && S[row + 1][col - 1] < 100)
							{
								S[row + 1][col - 1] += 200;
								break;
							}
							else
							{
								if (S[row + 1][col - 1] == 0)
									S[row + 1][col - 1] = 100;
							}
						}
					}
				}
				else
				{
					if (row + 1 >= 8)
					{
						if (col + 1 >= 8)		// XX
						{						// XO
							if (S[row - 1][col - 1] > 20 && S[row - 1][col - 1] < 100)
							{
								S[row - 1][col - 1] += 200;
								break;
							}
							else
							{
								if (S[row - 1][col - 1] == 0)
									S[row - 1][col - 1] = 100;
							}

							if (S[row - 1][col] > 20 && S[row - 1][col] < 100)
							{
								S[row - 1][col] += 200;
								break;
							}
							else
							{
								if (S[row - 1][col] == 0)
									S[row - 1][col] = 100;
							}

							if (S[row][col - 1] > 20 && S[row][col - 1] < 100)
							{
								S[row][col - 1] += 200;
								break;
							}
							else
							{
								if (S[row][col - 1] == 0)
									S[row][col - 1] = 100;
							}
						}
						else
						{
							if (col - 1 < 0)		// XX
							{						// OX
								if (S[row][col + 1] > 20 && S[row][col + 1] < 100)
								{
									S[row][col + 1] += 200;
									break;
								}
								else
								{
									if (S[row][col + 1] == 0)
										S[row][col + 1] = 100;
								}

								if (S[row - 1][col + 1] > 20 && S[row - 1][col + 1] < 100)
								{
									S[row - 1][col + 1] += 200;
									break;
								}
								else
								{
									if (S[row - 1][col + 1] == 0)
										S[row - 1][col + 1] = 100;
								}

								if (S[row - 1][col] > 20 && S[row - 1][col] < 100)
								{
									S[row - 1][col] += 200;
									break;
								}
								else
								{
									if (S[row - 1][col] == 0)
										S[row - 1][col] = 100;
								}
							}
							else		// XXX
							{			// XOX
								if (S[row - 1][col - 1] > 20 && S[row - 1][col - 1] < 100)
								{
									S[row - 1][col - 1] += 200;
									break;
								}
								else
								{
									if (S[row - 1][col - 1] == 0)
										S[row - 1][col - 1] = 100;
								}

								if (S[row - 1][col] > 20 && S[row - 1][col] < 100)
								{
									S[row - 1][col] += 200;
									break;
								}
								else
								{
									if (S[row - 1][col] == 0)
										S[row - 1][col] = 100;
								}

								if (S[row - 1][col + 1] > 20 && S[row - 1][col + 1] < 100)
								{
									S[row - 1][col + 1] += 200;
									break;
								}
								else
								{
									if (S[row - 1][col + 1] == 0)
										S[row - 1][col + 1] = 100;
								}

								if (S[row][col - 1] > 20 && S[row][col - 1] < 100)
								{
									S[row][col - 1] += 200;
									break;
								}
								else
								{
									if (S[row][col - 1] == 0)
										S[row][col - 1] = 100;
								}

								if (S[row][col + 1] > 20 && S[row][col + 1] < 100)
								{
									S[row][col + 1] += 200;
									break;
								}
								else
								{
									if (S[row][col + 1] == 0)
										S[row][col + 1] = 100;
								}

							}
						}
					}
					else
					{
						if (S[row - 1][col + 1] > 20 && S[row - 1][col + 1] < 100)
						{
							S[row - 1][col + 1] += 200;
							break;
						}
						else
						{
							if (S[row - 1][col + 1] == 0)
								S[row - 1][col + 1] = 100;
						}

						if (S[row - 1][col] > 20 && S[row - 1][col] < 100)
						{
							S[row - 1][col] += 200;
							break;
						}
						else
						{
							if (S[row - 1][col] == 0)
								S[row - 1][col] = 100;
						}

						if (S[row - 1][col - 1] > 20 && S[row - 1][col - 1] < 100)
						{
							S[row - 1][col - 1] += 200;
							break;
						}
						else
						{
							if (S[row - 1][col - 1] == 0)
								S[row - 1][col - 1] = 100;
						}

						if (S[row][col + 1] > 20 && S[row][col + 1] < 100)
						{
							S[row][col + 1] += 200;
							break;
						}
						else
						{
							if (S[row][col + 1] == 0)
								S[row][col + 1] = 100;
						}

						if (S[row][col - 1] > 20 && S[row][col - 1] < 100)
						{
							S[row][col - 1] += 200;
							break;
						}
						else
						{
							if (S[row][col - 1] == 0)
								S[row][col - 1] = 100;
						}

						if (S[row + 1][col - 1] > 20 && S[row + 1][col - 1] < 100)
						{
							S[row + 1][col - 1] += 200;
							break;
						}
						else
						{
							if (S[row + 1][col - 1] == 0)
								S[row + 1][col - 1] = 100;
						}

						if (S[row + 1][col] > 20 && S[row + 1][col] < 100)
						{
							S[row + 1][col] += 200;
							break;
						}
						else
						{
							if (S[row + 1][col] == 0)
								S[row + 1][col] = 100;
						}

						if (S[row + 1][col + 1] > 20 && S[row + 1][col + 1] < 100)
						{
							S[row + 1][col + 1] += 200;
							break;
						}
						else
						{
							if (S[row + 1][col + 1] == 0)
								S[row + 1][col + 1] = 100;
						}
					}
				}
			}
			default:
				break;
			
			}

			refreshScacchiera();


		}

		void azzeramentoScacchiera() {			// funzione che imposta tutti i valori neutrali

			resetColori();
			resetScacchiera();		// sfrutto l'impostazione dei trasparenti
			for (int i = 0; i < 8; i++)
				for (int j = 0; j < 8; j++)
					S[i][j] = 0;

			//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! manca il richiamo alla funzione che aggiorna le immagini

		}

		void setCaselleMosse() {	// funzione che imposta i colori in base ai valori della matrice S

			///*************************************** Verde *******************
			///		CASELLE 0x
			// cambia in verde la casella se � presente 100 nella matrice
			if(S[0][0] == 100)
				c00->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][1] == 100)
				c01->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][2] == 100)
				c02->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][3] == 100)
				c03->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][4] == 100)
				c04->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][5] == 100)
				c05->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][6] == 100)
				c06->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][7] == 100)
				c07->BackColor = CasVerde;

			///		CASELLE 1x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][0] == 100)
				c10->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][1] == 100)
				c11->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][2] == 100)
				c12->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][3] == 100)
				c13->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][4] == 100)
				c14->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][5] == 100)
				c15->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][6] == 100)
				c16->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][7] == 100)
				c17->BackColor = CasVerde;

			///		CASELLE 2x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][0] == 100)
				c20->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][1] == 100)
				c21->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][2] == 100)
				c22->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][3] == 100)
				c23->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][4] == 100)
				c24->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][5] == 100)
				c25->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][6] == 100)
				c26->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][7] == 100)
				c27->BackColor = CasVerde;

			///		CASELLE 3x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][0] == 100)
				c30->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][1] == 100)
				c31->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][2] == 100)
				c32->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][3] == 100)
				c33->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][4] == 100)
				c34->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][5] == 100)
				c35->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][6] == 100)
				c36->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][7] == 100)
				c37->BackColor = CasVerde;

			///		CASELLE 4x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][0] == 100)
				c40->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][1] == 100)
				c41->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][2] == 100)
				c42->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][3] == 100)
				c43->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][4] == 100)
				c44->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][5] == 100)
				c45->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][6] == 100)
				c46->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][7] == 100)
				c47->BackColor = CasVerde;

			///		CASELLE 5x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][0] == 100)
				c50->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][1] == 100)
				c51->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][2] == 100)
				c52->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][3] == 100)
				c53->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][4] == 100)
				c54->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][5] == 100)
				c55->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][6] == 100)
				c56->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][7] == 100)
				c57->BackColor = CasVerde;

			///		CASELLE 6x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][0] == 100)
				c60->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][1] == 100)
				c61->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][2] == 100)
				c62->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][3] == 100)
				c63->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][4] == 100)
				c64->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][5] == 100)
				c65->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][6] == 100)
				c66->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][7] == 100)
				c67->BackColor = CasVerde;
			
			///		CASELLE 7x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][0] == 100)
				c70->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][1] == 100)
				c71->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][2] == 100)
				c72->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][3] == 100)
				c73->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][4] == 100)
				c74->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][5] == 100)
				c75->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][6] == 100)
				c76->BackColor = CasVerde;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][7] == 100)
				c77->BackColor = CasVerde;


			///*************************************** Rosso *******************
			///		CASELLE 0x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][0] > 200)
				c00->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][1] > 200)
				c01->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][2] > 200)
				c02->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][3] > 200)
				c03->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][4] > 200)
				c04->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][5] > 200)
				c05->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][6] > 200)
				c06->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[0][7] > 200)
				c07->BackColor = CasRossa;

			///		CASELLE 1x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][0] > 200)
				c10->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][1] > 200)
				c11->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][2] > 200)
				c12->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][3] > 200)
				c13->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][4] > 200)
				c14->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][5] > 200)
				c15->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][6] > 200)
				c16->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[1][7] > 200)
				c17->BackColor = CasRossa;

			///		CASELLE 2x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][0] > 200)
				c20->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][1] > 200)
				c21->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][2] > 200)
				c22->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][3] > 200)
				c23->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][4] > 200)
				c24->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][5] > 200)
				c25->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][6] > 200)
				c26->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[2][7] > 200)
				c27->BackColor = CasRossa;

			///		CASELLE 3x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][0] > 200)
				c30->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][1] > 200)
				c31->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][2] > 200)
				c32->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][3] > 200)
				c33->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][4] > 200)
				c34->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][5] > 200)
				c35->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][6] > 200)
				c36->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[3][7] > 200)
				c37->BackColor = CasRossa;

			///		CASELLE 4x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][0] > 200)
				c40->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][1] > 200)
				c41->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][2] > 200)
				c42->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][3] > 200)
				c43->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][4] > 200)
				c44->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][5] > 200)
				c45->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][6] > 200)
				c46->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[4][7] > 200)
				c47->BackColor = CasRossa;

			///		CASELLE 5x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][0] > 200)
				c50->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][1] > 200)
				c51->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][2] > 200)
				c52->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][3] > 200)
				c53->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][4] > 200)
				c54->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][5] > 200)
				c55->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][6] > 200)
				c56->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[5][7] > 200)
				c57->BackColor = CasRossa;

			///		CASELLE 6x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][0] > 200)
				c60->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][1] > 200)
				c61->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][2] > 200)
				c62->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][3] > 200)
				c63->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][4] > 200)
				c64->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][5] > 200)
				c65->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][6] > 200)
				c66->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[6][7] > 200)
				c67->BackColor = CasRossa;

			///		CASELLE 7x
			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][0] > 200)
				c70->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][1] > 200)
				c71->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][2] > 200)
				c72->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][3] > 200)
				c73->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][4] > 200)
				c74->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][5] > 200)
				c75->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][6] > 200)
				c76->BackColor = CasRossa;

			// cambia in verde la casella se � presente 100 nella matrice
			if (S[7][7] > 200)
				c77->BackColor = CasRossa;



		}

	
		///------------ FUNZIONI AI

		void Start(int X1, int Y1, int X2, int Y2)		// passo le mosse 
		{
			
			int Moved, Taken;

			Depth = eloAi;          // profondit� di ricerca --> elo

			ClearMobility();                 //...

			
			HumanMoveGenerator(X1, Y1, 3);

			if (AttackedH[X2][Y2] != 0)
			{
				MakeMovement(X1, Y1, X2, Y2, Moved, Taken);
				MoveNo++;
				
				StartSearch();
				MakeMovement(BestMove[0], BestMove[1], BestMove[2], BestMove[3], Moved, Taken);
				MoveNo++;
				
				int x1 = 0;
				int y1 = 0;
				int x2 = 0;
				int y2 = 0;

				convertitoreIndiciRitorno((BestMove[0]), (BestMove[1]), (BestMove[2]), (BestMove[3]), x1, y1, x2, y2);
				

				if (S[y2][x2] > 20)		// controlla se si clicca una casella rossa
				{

					switch (S[y2][x2])
					{
					case 21:
					{
						mangiatiB[0]++;

						break;
					}
					case 22:
					{
						mangiatiB[0]++;

						break;
					}
					case 23:
					{
						mangiatiB[1]++;

						break;
					}
					case 24:
					{
						mangiatiB[2]++;

						break;
					}
					case 25:
					{
						mangiatiB[3]++;

						break;
					}
					case 26:
					{
						mangiatiB[4]++;

						break;
					}
					case 30:
					{
						mangiatiB[5]++;

						break;
					}

					default:
						break;
					}
					
				}

				S[y2][x2] = S[y1][x1];
				S[y1][x1] = 0;
				refreshScacchiera();

				
			}

			turn = !turn;
		}

		//******************************************************************************************
		//******************SUPPORT FUNCTIONS*******************************************************
		//******************************************************************************************

		//Sets the board to original positions
		void NewGame()
		{
			for (int X = 0; X <= 11; X++)
			{
				for (int Y = 0; Y <= 11; Y++)
				{
					Board[X][Y] = 2;
					if ((X > 1) && (X < 10) && (Y > 1) && (Y < 10))
					{
						Board[X][Y] = 0;
					}
				}
			}
			Board[2][2] = -Rook; Board[3][2] = -Knight; Board[2][9] = Rook; Board[3][9] = Knight;
			Board[4][2] = -Bishop; Board[5][2] = -Queen; Board[4][9] = Bishop; Board[5][9] = Queen;
			Board[6][2] = -King; Board[7][2] = -Bishop; Board[6][9] = King; Board[7][9] = Bishop;
			Board[8][2] = -Knight; Board[9][2] = -Rook; Board[8][9] = Knight; Board[9][9] = Rook;
			Board[2][3] = -Pawn; Board[3][3] = -Pawn; Board[2][8] = Pawn; Board[3][8] = Pawn;
			Board[4][3] = -Pawn; Board[5][3] = -Pawn; Board[4][8] = Pawn; Board[5][8] = Pawn;
			Board[6][3] = -Pawn; Board[7][3] = -Pawn; Board[6][8] = Pawn; Board[7][8] = Pawn;
			Board[8][3] = -Pawn; Board[9][3] = -Pawn; Board[8][8] = Pawn; Board[9][8] = Pawn;
			MoveNo = 0;
			//PrintBoard();
		}

		//Makes a move on board for human or computer
		void MakeMovement(int X1, int Y1, int X2, int Y2, int &Moved, int &Taken)			// inserisce nella matrice virtuale la mossa effettuata sia dall'utente che dall'AI
		{
			Taken = Board[X2][Y2];
			Moved = Board[X1][Y1];
			Board[X2][Y2] = Moved;
			Board[X1][Y1] = 0;
			if ((Y2 == 2) && (Moved == Pawn)) Board[X2][Y2] = Queen;						// se il pedone arriva in fondo diventa regina
			if ((Y2 == 9) && (Moved == -Pawn)) Board[X2][Y2] = -Queen;
		}

		//UnMakes a move on board for human or computer
		void UnMakeMovement(int X1, int Y1, int X2, int Y2, int Moved, int Taken)
		{
			Board[X1][Y1] = Moved;
			Board[X2][Y2] = Taken;
		}

		//Clears both matrixes of attacked squares
		void ClearMobility()								// pulisce la matrici dell'attacco dei pezzi
		{
			for (int X = 0; X <= 11; X++)  //Goes through the whole board matrix
			{
				for (int Y = 0; Y <= 11; Y++)
				{
					AttackedC[X][Y] = 0;
					AttackedH[X][Y] = 0;
				}
			}
		}

		//******************************************************************************************
		//******************SEARCH FUNCTIONS********************************************************
		//******************************************************************************************

		//Starts the search process
		void StartSearch()
		{
			for (int X = 0; X <= 19; X++) { Value[X] = 0; }//Reset the layers values.
			for (int X = 0; X <= 3; X++) { BestMove[X] = 0; }//Reset the best move found.
			State = GameState();			// indica in che parte del gioco ci si trova se apertura, mediogioco o finale
			Value[0] = 32000;
			Value[1] = -32000;
			Abort = 0;
			Nodes = 0;
			CurrentDepth = 1;
			AllComputerMoves();
		}

		//Search for all computer possible moves in the current board.
		void AllComputerMoves()
		{
			for (int X = 2; X <= 9; X++)
			{
				for (int Y = 2; Y <= 9; Y++)
				{
					if (Board[X][Y] > 0) {
						ComputerMoveGenerator(X, Y, 1);

						if (Abort == 1)
						{
							Abort = 0; return;
						}
					}
				}
			}
		}

		//Search for all human possible moves in the current board.
		void AllHumanMoves()
		{
			for (int X = 2; X <= 9; X++)
			{
				for (int Y = 2; Y <= 9; Y++)
				{
					if (Board[X][Y] < 0) {
						HumanMoveGenerator(X, Y, 1);
						if (Abort == 1) {
							Abort = 0;
							return;
						}
					}
				}
			}
		}

		//Simulates a movement on the board for computer.
		void ComputerMove(int X1, int Y1, int X2, int Y2)
		{
			int Moved, Taken;
			CurrentDepth++;
			Nodes++;
			MakeMovement(X1, Y1, X2, Y2, Moved, Taken);
			if (Taken == -King) { Value[CurrentDepth] = Evaluation(); }
			else { Value[CurrentDepth] = Value[CurrentDepth - 2]; AllHumanMoves(); }
			if (Value[CurrentDepth] > Value[CurrentDepth - 1] && CurrentDepth > 2) { Value[CurrentDepth - 1] = Value[CurrentDepth]; }
			if (Value[CurrentDepth - 1] >= Value[CurrentDepth - 2] && CurrentDepth > 2) { Abort = 1; }
			if (CurrentDepth == 2 && Value[2] > Value[1])
			{
				Value[1] = Value[2];
				BestMove[0] = X1; BestMove[1] = Y1;
				BestMove[2] = X2; BestMove[3] = Y2;
			}
			UnMakeMovement(X1, Y1, X2, Y2, Moved, Taken);
			CurrentDepth--;
		}

		//Simulates a movement on the board for human.
		void HumanMove(int X1, int Y1, int X2, int Y2)
		{
			int Moved, Taken;
			CurrentDepth++;
			Nodes++;
			MakeMovement(X1, Y1, X2, Y2, Moved, Taken);
			if (Taken == King || CurrentDepth >= Depth) { Value[CurrentDepth] = Evaluation(); }
			else { Value[CurrentDepth] = Value[CurrentDepth - 2]; AllComputerMoves(); }
			if (Value[CurrentDepth] < Value[CurrentDepth - 1]) { Value[CurrentDepth - 1] = Value[CurrentDepth]; }
			if (Value[CurrentDepth - 1] <= Value[CurrentDepth - 2]) { Abort = 1; }
			UnMakeMovement(X1, Y1, X2, Y2, Moved, Taken);
			CurrentDepth--;
		}

		//******************************************************************************************
		//******************MOVE GENERATOR**********************************************************
		//******************************************************************************************

		//Move generator for Computer moves
		void ComputerMoveGenerator(int X1, int Y1, int MoveType)
		{
			switch (Board[X1][Y1])
			{
			case 10:
				if (Y1 == 8 && Board[X1][Y1 - 1] == 0 && Board[X1][Y1 - 2] == 0 && Board[X1 + 1][Y1 - 2] != -Pawn && Board[X1 - 1][Y1 - 2] != -Pawn)
					ComputerMoveType(X1, Y1, X1, Y1 - 2, MoveType);
				if (Board[X1][Y1 - 1] == 0)
					ComputerMoveType(X1, Y1, X1, Y1 - 1, MoveType);
				if (Board[X1 + 1][Y1 - 1] < 0)
					ComputerMoveType(X1, Y1, X1 + 1, Y1 - 1, MoveType);
				if (Board[X1 - 1][Y1 - 1] < 0)
					ComputerMoveType(X1, Y1, X1 - 1, Y1 - 1, MoveType);
				break;

			case 30:
				if (Board[X1 + 2][Y1 + 1] <= 0)
					ComputerMoveType(X1, Y1, X1 + 2, Y1 + 1, MoveType);
				if (Board[X1 + 2][Y1 - 1] <= 0)
					ComputerMoveType(X1, Y1, X1 + 2, Y1 - 1, MoveType);
				if (Board[X1 - 2][Y1 - 1] <= 0)
					ComputerMoveType(X1, Y1, X1 - 2, Y1 - 1, MoveType);
				if (Board[X1 - 2][Y1 + 1] <= 0)
					ComputerMoveType(X1, Y1, X1 - 2, Y1 + 1, MoveType);
				if (Board[X1 + 1][Y1 + 2] <= 0)
					ComputerMoveType(X1, Y1, X1 + 1, Y1 + 2, MoveType);
				if (Board[X1 - 1][Y1 + 2] <= 0)
					ComputerMoveType(X1, Y1, X1 - 1, Y1 + 2, MoveType);
				if (Board[X1 + 1][Y1 - 2] <= 0)
					ComputerMoveType(X1, Y1, X1 + 1, Y1 - 2, MoveType);
				if (Board[X1 - 1][Y1 - 2] <= 0)
					ComputerMoveType(X1, Y1, X1 - 1, Y1 - 2, MoveType);
				break;

			case 10000:
				if (Board[X1 + 1][Y1 + 1] <= 0)
					ComputerMoveType(X1, Y1, X1 + 1, Y1 + 1, MoveType);
				if (Board[X1 - 1][Y1 + 1] <= 0)
					ComputerMoveType(X1, Y1, X1 - 1, Y1 + 1, MoveType);
				if (Board[X1 - 1][Y1 - 1] <= 0)
					ComputerMoveType(X1, Y1, X1 - 1, Y1 - 1, MoveType);
				if (Board[X1 + 1][Y1 - 1] <= 0)
					ComputerMoveType(X1, Y1, X1 + 1, Y1 - 1, MoveType);
				if (Board[X1][Y1 - 1] <= 0)
					ComputerMoveType(X1, Y1, X1, Y1 - 1, MoveType);
				if (Board[X1][Y1 + 1] <= 0)
					ComputerMoveType(X1, Y1, X1, Y1 + 1, MoveType);
				if (Board[X1 - 1][Y1] <= 0)
					ComputerMoveType(X1, Y1, X1 - 1, Y1, MoveType);
				if (Board[X1 + 1][Y1] <= 0)
					ComputerMoveType(X1, Y1, X1 + 1, Y1, MoveType);
				break;

			case 32:
				ComputerLongMoves(X1, Y1, 1, 1, MoveType);
				ComputerLongMoves(X1, Y1, 1, -1, MoveType);
				ComputerLongMoves(X1, Y1, -1, -1, MoveType);
				ComputerLongMoves(X1, Y1, -1, 1, MoveType);
				break;

			case 50:
				ComputerLongMoves(X1, Y1, 0, 1, MoveType);
				ComputerLongMoves(X1, Y1, 0, -1, MoveType);
				ComputerLongMoves(X1, Y1, 1, 0, MoveType);
				ComputerLongMoves(X1, Y1, -1, 0, MoveType);
				break;

			case 90:
				ComputerLongMoves(X1, Y1, 0, 1, MoveType);
				ComputerLongMoves(X1, Y1, 0, -1, MoveType);
				ComputerLongMoves(X1, Y1, 1, 0, MoveType);
				ComputerLongMoves(X1, Y1, -1, 0, MoveType);
				ComputerLongMoves(X1, Y1, 1, 1, MoveType);
				ComputerLongMoves(X1, Y1, 1, -1, MoveType);
				ComputerLongMoves(X1, Y1, -1, -1, MoveType);
				ComputerLongMoves(X1, Y1, -1, 1, MoveType);
				break;
			}
		}

		//Generates computer long moves
		void ComputerLongMoves(int X1, int Y1, int MX, int MY, int MoveType)
		{
			int CX = MX;
			int CY = MY;
			int Square;
			while (Board[X1 + CX][Y1 + CY] != 2)
			{
				Square = Board[X1 + CX][Y1 + CY];
				if (Square == 0) { ComputerMoveType(X1, Y1, X1 + CX, Y1 + CY, MoveType); }
				if (Square < 0) { ComputerMoveType(X1, Y1, X1 + CX, Y1 + CY, MoveType);  return; }
				if (Square > 0) { return; }
				CX = CX + MX;
				CY = CY + MY;
			}
		}

		//Generates an action upon a computer move
		void ComputerMoveType(int X1, int Y1, int X2, int Y2, int MoveType)
		{
			if (MoveType == 1) { ComputerMove(X1, Y1, X2, Y2); return; }
			if (MoveType == 3) { AttackedC[X2][Y2] = AttackedC[X2][Y2] + 1; return; }
		}

		//Move generator for Human moves
		void HumanMoveGenerator(int X1, int Y1, int MoveType)					// AI utilizza la generazione delle mosse possibili umane per calcolare i vari rami
		{

			//MessageBox::Show("HumanMoveGenerator: " + MoveType + "   " + Board[X1][Y1]);

			switch (Board[X1][Y1])
			{
			case -10:				// caso del pedone
				if (Y1 == 3 && Board[X1][Y1 + 1] == 0 && Board[X1][Y1 + 2] == 0 && Board[X1 + 1][Y1 + 2] != Pawn && Board[X1 - 1][Y1 + 2] != Pawn)
					HumanMoveType(X1, Y1, X1, Y1 + 2, MoveType);
				if (Board[X1][Y1 + 1] == 0)HumanMoveType(X1, Y1, X1, Y1 + 1, MoveType);
				if (Board[X1 + 1][Y1 + 1] > 0 && Board[X1 + 1][Y1 + 1] != 2)
					HumanMoveType(X1, Y1, X1 + 1, Y1 + 1, MoveType);
				if (Board[X1 - 1][Y1 + 1] > 0 && Board[X1 - 1][Y1 + 1] != 2)
					HumanMoveType(X1, Y1, X1 - 1, Y1 + 1, MoveType);
				break;

			case -30:			// cavallo
				if (Board[X1 + 2][Y1 + 1] >= 0 && Board[X1 + 2][Y1 + 1] != 2)
					HumanMoveType(X1, Y1, X1 + 2, Y1 + 1, MoveType);
				if (Board[X1 + 2][Y1 - 1] >= 0 && Board[X1 + 2][Y1 - 1] != 2)
					HumanMoveType(X1, Y1, X1 + 2, Y1 - 1, MoveType);
				if (Board[X1 - 2][Y1 - 1] >= 0 && Board[X1 - 2][Y1 - 1] != 2)
					HumanMoveType(X1, Y1, X1 - 2, Y1 - 1, MoveType);
				if (Board[X1 - 2][Y1 + 1] >= 0 && Board[X1 - 2][Y1 + 1] != 2)
					HumanMoveType(X1, Y1, X1 - 2, Y1 + 1, MoveType);
				if (Board[X1 + 1][Y1 + 2] >= 0 && Board[X1 + 1][Y1 + 2] != 2)
					HumanMoveType(X1, Y1, X1 + 1, Y1 + 2, MoveType);
				if (Board[X1 - 1][Y1 + 2] >= 0 && Board[X1 - 1][Y1 + 2] != 2)
					HumanMoveType(X1, Y1, X1 - 1, Y1 + 2, MoveType);
				if (Board[X1 + 1][Y1 - 2] >= 0 && Board[X1 + 1][Y1 - 2] != 2)
					HumanMoveType(X1, Y1, X1 + 1, Y1 - 2, MoveType);
				if (Board[X1 - 1][Y1 - 2] >= 0 && Board[X1 - 1][Y1 - 2] != 2)
					HumanMoveType(X1, Y1, X1 - 1, Y1 - 2, MoveType);
				break;

			case -10000:				// re
				if (Board[X1 + 1][Y1 + 1] >= 0 && Board[X1 + 1][Y1 + 1] != 2)
					HumanMoveType(X1, Y1, X1 + 1, Y1 + 1, MoveType);
				if (Board[X1 - 1][Y1 + 1] >= 0 && Board[X1 - 1][Y1 + 1] != 2)
					HumanMoveType(X1, Y1, X1 - 1, Y1 + 1, MoveType);
				if (Board[X1 - 1][Y1 - 1] >= 0 && Board[X1 - 1][Y1 - 1] != 2)
					HumanMoveType(X1, Y1, X1 - 1, Y1 - 1, MoveType);
				if (Board[X1 + 1][Y1 - 1] >= 0 && Board[X1 + 1][Y1 - 1] != 2)
					HumanMoveType(X1, Y1, X1 + 1, Y1 - 1, MoveType);
				if (Board[X1][Y1 - 1] >= 0 && Board[X1][Y1 - 1] != 2)
					HumanMoveType(X1, Y1, X1, Y1 - 1, MoveType);
				if (Board[X1][Y1 + 1] >= 0 && Board[X1][Y1 + 1] != 2)
					HumanMoveType(X1, Y1, X1, Y1 + 1, MoveType);
				if (Board[X1 - 1][Y1] >= 0 && Board[X1 - 1][Y1] != 2)
					HumanMoveType(X1, Y1, X1 - 1, Y1, MoveType);
				if (Board[X1 + 1][Y1] >= 0 && Board[X1 + 1][Y1] != 2)
					HumanMoveType(X1, Y1, X1 + 1, Y1, MoveType);
				break;

			case -32:		// alfiere
				HumanLongMoves(X1, Y1, 1, 1, MoveType);
				HumanLongMoves(X1, Y1, 1, -1, MoveType);
				HumanLongMoves(X1, Y1, -1, -1, MoveType);
				HumanLongMoves(X1, Y1, -1, 1, MoveType);
				break;
			case -50:			// torre
				HumanLongMoves(X1, Y1, 0, 1, MoveType);
				HumanLongMoves(X1, Y1, 0, -1, MoveType);
				HumanLongMoves(X1, Y1, 1, 0, MoveType);
				HumanLongMoves(X1, Y1, -1, 0, MoveType);
				break;
			case -90:			// regina
				HumanLongMoves(X1, Y1, 0, 1, MoveType);
				HumanLongMoves(X1, Y1, 0, -1, MoveType);
				HumanLongMoves(X1, Y1, 1, 0, MoveType);
				HumanLongMoves(X1, Y1, -1, 0, MoveType);
				HumanLongMoves(X1, Y1, 1, 1, MoveType);
				HumanLongMoves(X1, Y1, 1, -1, MoveType);
				HumanLongMoves(X1, Y1, -1, -1, MoveType);
				HumanLongMoves(X1, Y1, -1, 1, MoveType);
				break;
			}
		}

		//Generates human long moves
		void HumanLongMoves(int X1, int Y1, int MX, int MY, int MoveType)				// MX e MY sono colonne e righe, assumono i valori 0, 1, -1 come nel piano cartesiano
		{
			int CX = MX;
			int CY = MY;
			int Square;
			while (Board[X1 + CX][Y1 + CY] != 2)
			{
				Square = Board[X1 + CX][Y1 + CY];
				if (Square == 0) { HumanMoveType(X1, Y1, X1 + CX, Y1 + CY, MoveType); }				// == 0, la casella � libera
				if (Square > 0) { HumanMoveType(X1, Y1, X1 + CX, Y1 + CY, MoveType);  return; }		// > 0, la casella contiene un pezzo avversario
				if (Square < 0) { return; }															// < 0, la casella � occupato da un pezzo amico
				CX = CX + MX;					// incremento della distanza dal punto iniziale
				CY = CY + MY;
			}
		}

		//Generates an action upon a Human move
		void HumanMoveType(int X1, int Y1, int X2, int Y2, int MoveType)
		{
			//MessageBox::Show("HumanMoveType: " + MoveType);


			if (MoveType == 1)
			{
				HumanMove(X1, Y1, X2, Y2);
				return;
			}

			if (MoveType == 3)
			{
				//MessageBox::Show("bla");
				AttackedH[X2][Y2] = AttackedH[X2][Y2] + 1;
				return;
			}
		}

		//******************************************************************************************
		//******************EVALUATION FUNCTIONS****************************************************
		//******************************************************************************************

		//Fast board evaluation - Evaluates board value + board positions - Sate of Game.
		int Evaluation()
		{
			int Evaluation2 = 0;
			if (State == 1) { Evaluation2 = Material() + Development(); }
			if (State == 2) { Evaluation2 = Material() + Development() + HumanAproach(6, 8) - ComputerAproach(6, 3); }
			if (State == 3)
			{
				int XCK = 0, YCK = 0, XHK = 0, YHK = 0;
				KingCoordinates(XCK, YCK, XHK, YHK);
				Evaluation2 = Material() + Development() + PossibleCrown() + HumanAproach(XCK, YCK) - ComputerAproach(XHK, YHK);
			}
			return Evaluation2;
		}

		//Calculates game state (oppening, middle, end)
		int GameState()
		{
			int GameState2 = 2;
			if (MoveNo < 12) { GameState2 = 1; }
			if (MoveNo > 30) { GameState2 = 3; }
			return GameState2;
		}

		//Calculates all board piece values.
		int Material()
		{
			int Material2 = 0;
			for (int X = 2; X <= 9; X++)
			{
				for (int Y = 2; Y <= 9; Y++) { Material2 += Board[X][Y]; }
			}
			return Material2;
		}

		//Evaluates how well the pieces have been developed.
		int Development()
		{
			int Development2 = 0;
			if (Board[6][6] == Pawn) { Development2 = Development2 + 5; }
			if (Board[5][6] == Pawn) { Development2 = Development2 + 5; }
			if (Board[3][9] == 0) { Development2 = Development2 + 2; }
			if (Board[4][9] == 0) { Development2 = Development2 + 2; }
			if (Board[7][9] == 0) { Development2 = Development2 + 4; }
			if (Board[8][9] == 0) { Development2 = Development2 + 2; }
			if (Board[3][2] == 0) { Development2 = Development2 - 2; }
			if (Board[4][2] == 0) { Development2 = Development2 - 2; }
			if (Board[7][2] == 0) { Development2 = Development2 - 4; }
			if (Board[8][2] == 0) { Development2 = Development2 - 4; }
			for (int X = 5; X <= 6; X++)
			{
				for (int Y = 4; Y <= 7; Y++)
				{
					if (Board[X][Y] == Pawn) { Development2 = Development2 + 4; }
					if (Board[X][Y] == -Pawn) { Development2 = Development2 - 4; }
				}
			}
			return Development2;
		}

		//Evaluates how close a pawn is to be crowned.
		int PossibleCrown()
		{
			int PossibleCrown2 = 0;
			for (int X = 2; X <= 9; X++)
			{
				if (Board[X][3] == Pawn) { PossibleCrown2 = PossibleCrown2 + 15; }
				if (Board[X][4] == Pawn) { PossibleCrown2 = PossibleCrown2 + 10; }
				if (Board[X][5] == Pawn) { PossibleCrown2 = PossibleCrown2 + 5; }
				if (Board[X][8] == -Pawn) { PossibleCrown2 = PossibleCrown2 - 15; }
				if (Board[X][7] == -Pawn) { PossibleCrown2 = PossibleCrown2 + 10; }
				if (Board[X][6] == -Pawn) { PossibleCrown2 = PossibleCrown2 + 5; }
			}
			return PossibleCrown2;
		}

		//Evaluates how close a piece is to it�s objective for human.
		int HumanAproach(int X2, int Y2)
		{
			double HumanAproach2 = 0;
			double Temp = 0;
			for (int X = 2; X <= 9; X++)
			{
				for (int Y = 2; Y <= 9; Y++)
				{
					if (Board[X][Y] < -Pawn && Board[X][Y] > -King)
					{
						Temp = pow(abs(X - X2), 2) + pow(abs(Y - Y2), 2);
						HumanAproach2 = HumanAproach2 + sqrt(Temp);
					}
					if (State == 3)
					{
						if (Board[X][Y] == -King)
						{
							Temp = pow(abs(X - X2), 2) + pow(abs(Y - Y2), 2);
							HumanAproach2 = HumanAproach2 + (4 * (sqrt(Temp)));
						}
					}
				}
			}
			return floor(HumanAproach2);
		}

		//Evaluates how close a piece is to it�s objective for computer.
		int ComputerAproach(int X2, int Y2)
		{
			double ComputerAproach2 = 0;
			double Temp = 0;
			for (int X = 2; X <= 9; X++)
			{
				for (int Y = 2; Y <= 9; Y++)
				{
					if (Board[X][Y] > Pawn && Board[X][Y] < King)
					{
						Temp = pow(abs(X - X2), 2) + pow(abs(Y - Y2), 2);
						ComputerAproach2 = ComputerAproach2 + sqrt(Temp);
					}
					if (State == 3)
					{
						if (Board[X][Y] == King)
						{
							Temp = pow(abs(X - X2), 2) + pow(abs(Y - Y2), 2);
							ComputerAproach2 = ComputerAproach2 + (4 * sqrt(Temp));
						}
					}
				}
			}
			return floor(ComputerAproach2);
		}

		//Returns the King�s coordinates
		void KingCoordinates(int &XCK, int &YCK, int &XHK, int &YHK)
		{
			for (int X = 2; X <= 9; X++)
			{
				for (int Y = 2; Y <= 9; Y++)
				{
					if (Board[X][Y] == -King) { XHK = X; YHK = Y; }
					if (Board[X][Y] == King) { XCK = X; YCK = Y; }
				}
			}
		}

		///----------------------------


	protected:
		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>

		~Game()
		{
			if (components)
			{
				delete components;
			}
		}

	private: void playMoveSound() {

		SoundPlayer ^ simpleSound = gcnew SoundPlayer(Application::StartupPath + "\\..\\sound\\" + "move.wav");
		simpleSound->Play();

	}

	/// VARIABILI DI AI
	private:
		//Matrixes
		int **Board;	//12*12
		int **AttackedH;	//12*12
		int **AttackedC;	//12*12
		int *Value;

		//Constant Pieces
		const int King = 10000;
		const int Queen = 90;
		const int Rook = 50;
		const int Bishop = 32;
		const int Knight = 30;
		const int Pawn = 10;

		//Variables
		int CurrentDepth;
		int Depth;
		int Abort;
		int State;
		int MoveNo;
		int *BestMove;
		long int Nodes;

	///--------------------------

	private: bool sReB = true;
	private: bool sTorreDXB = true;
	private: bool sTorreSXB = true;
	private: bool sReN = true;
	private: bool sTorreDXN = true;
	private: bool sTorreSXN = true;
	private: int eloAi;
	private: int indexGame;
	private: String^ gioc1 = "Giocatore1";
	private: String^ gioc2 = "Giocatore2";
	private: int rowConsole = '4';												// valore associato alla riga della console
	private: int colConsole = '4';												// valore associato alla colonna della console
	private: int pezzoConsole = '2';												// valore associato al pezzo della console
	private: int coloreConsole = '1';												// valore associato al colore della console
	private: int nTurni = 0;							//!!!!!!!!!!!!!! implementare 
	private: int indiceRowValorePezzoAttuale = 0;									// memorizzo il valore numerico assegnato al pezzo cliccato
	private: int indiceColValorePezzoAttuale = 0;									// memorizzo il valore numerico assegnato al pezzo cliccato
	private: Color CasBlu = System::Drawing::Color::FromArgb(102, 178, 255);		// colore della casella del pezzo --> blu
	private: Color CasVerde = System::Drawing::Color::FromArgb(116, 225, 104);		// colore della casella di arrivo senza pezzi nemici --> verde
	private: Color CasRossa = System::Drawing::Color::FromArgb(225, 104, 104);		// colore della casella di arrivo --> rosso
	private: Color Trasparente = System::Drawing::Color::Transparent;				// colore della casella default
	private: bool turn = true;														// true: bianco, false: nero
	private: int **S;																// Matrice
	private: int *mangiatiB;														// pezzi mangiati del bianco
	private: int *mangiatiN;														// pezzi mangiati del nero
	private: System::Windows::Forms::Panel^  scacchiera;
	private: System::Windows::Forms::PictureBox^  c57;
	protected:

	protected:


	private: System::Windows::Forms::PictureBox^  c53;

	private: System::Windows::Forms::PictureBox^  c37;
	private: System::Windows::Forms::PictureBox^  c47;


	private: System::Windows::Forms::PictureBox^  c33;
	private: System::Windows::Forms::PictureBox^  c55;


	private: System::Windows::Forms::PictureBox^  c27;
	private: System::Windows::Forms::PictureBox^  c43;


	private: System::Windows::Forms::PictureBox^  c35;
	private: System::Windows::Forms::PictureBox^  c51;


	private: System::Windows::Forms::PictureBox^  c23;
	private: System::Windows::Forms::PictureBox^  c45;


	private: System::Windows::Forms::PictureBox^  c31;
	private: System::Windows::Forms::PictureBox^  c56;


	private: System::Windows::Forms::PictureBox^  c25;
	private: System::Windows::Forms::PictureBox^  c41;


	private: System::Windows::Forms::PictureBox^  c36;
	private: System::Windows::Forms::PictureBox^  c52;


	private: System::Windows::Forms::PictureBox^  c21;
	private: System::Windows::Forms::PictureBox^  c46;


	private: System::Windows::Forms::PictureBox^  c32;
	private: System::Windows::Forms::PictureBox^  c54;


	private: System::Windows::Forms::PictureBox^  c26;
	private: System::Windows::Forms::PictureBox^  c42;


	private: System::Windows::Forms::PictureBox^  c34;
	private: System::Windows::Forms::PictureBox^  c50;


	private: System::Windows::Forms::PictureBox^  c22;
	private: System::Windows::Forms::PictureBox^  c44;




	private: System::Windows::Forms::PictureBox^  c30;
	private: System::Windows::Forms::PictureBox^  c40;


	private: System::Windows::Forms::PictureBox^  c24;

	private: System::Windows::Forms::PictureBox^  c20;

	private: System::Windows::Forms::PictureBox^  c03;

	private: System::Windows::Forms::PictureBox^  c06;
	private: System::Windows::Forms::PictureBox^  c07;
	private: System::Windows::Forms::PictureBox^  c00;
	private: System::Windows::Forms::PictureBox^  c05;
	private: System::Windows::Forms::PictureBox^  c02;
	private: System::Windows::Forms::PictureBox^  c01;
	private: System::Windows::Forms::PictureBox^  c17;

	private: System::Windows::Forms::PictureBox^  c13;
	private: System::Windows::Forms::PictureBox^  c15;


	private: System::Windows::Forms::PictureBox^  c11;
	private: System::Windows::Forms::PictureBox^  c16;


	private: System::Windows::Forms::PictureBox^  c12;
	private: System::Windows::Forms::PictureBox^  c14;
private: System::Windows::Forms::PictureBox^  c67;
private: System::Windows::Forms::PictureBox^  c73;




private: System::Windows::Forms::PictureBox^  c63;
private: System::Windows::Forms::PictureBox^  c65;
private: System::Windows::Forms::PictureBox^  c76;




private: System::Windows::Forms::PictureBox^  c75;

private: System::Windows::Forms::PictureBox^  c72;

private: System::Windows::Forms::PictureBox^  c71;

private: System::Windows::Forms::PictureBox^  c66;
private: System::Windows::Forms::PictureBox^  c74;


private: System::Windows::Forms::PictureBox^  c61;
private: System::Windows::Forms::PictureBox^  c64;


private: System::Windows::Forms::PictureBox^  c62;
private: System::Windows::Forms::PictureBox^  c77;


private: System::Windows::Forms::PictureBox^  c70;

private: System::Windows::Forms::PictureBox^  c60;

	private: System::Windows::Forms::PictureBox^  c10;

	private: System::Windows::Forms::PictureBox^  c04;
private: System::Windows::Forms::Label^  LabelTurno;



private: System::Windows::Forms::Button^  enter;
private: System::Windows::Forms::Button^  istr;
private: System::Windows::Forms::Button^  reset;
private: System::Windows::Forms::TextBox^  pezzo;
private: System::Windows::Forms::TextBox^  idRiga;
private: System::Windows::Forms::TextBox^  idColonna;



private: System::Windows::Forms::Label^  stato;

private: System::Windows::Forms::Label^  label2;
private: System::Windows::Forms::Label^  label3;
private: System::Windows::Forms::Label^  label4;
private: System::Windows::Forms::Label^  label5;
private: System::Windows::Forms::PictureBox^  pictureBox1;
private: System::Windows::Forms::PictureBox^  pictureBox2;
private: System::Windows::Forms::PictureBox^  pictureBox3;
private: System::Windows::Forms::PictureBox^  pictureBox4;
private: System::Windows::Forms::PictureBox^  pictureBox5;
private: System::Windows::Forms::PictureBox^  pictureBox6;
private: System::Windows::Forms::PictureBox^  pictureBox7;
private: System::Windows::Forms::PictureBox^  pictureBox8;
private: System::Windows::Forms::PictureBox^  pictureBox9;
private: System::Windows::Forms::PictureBox^  pictureBox10;
private: System::Windows::Forms::Label^  label1;
private: System::Windows::Forms::Label^  label6;
private: System::Windows::Forms::Label^  label7;
private: System::Windows::Forms::Label^  label8;
private: System::Windows::Forms::Label^  label9;
private: System::Windows::Forms::Label^  label10;
private: System::Windows::Forms::Label^  label11;
private: System::Windows::Forms::Label^  label12;
private: System::Windows::Forms::Label^  label13;
private: System::Windows::Forms::Label^  label14;
private: System::Windows::Forms::Label^  g1;
private: System::Windows::Forms::Label^  g2;
private: System::Windows::Forms::Label^  label15;


	protected:



	private:
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Game::typeid));
			this->scacchiera = (gcnew System::Windows::Forms::Panel());
			this->c57 = (gcnew System::Windows::Forms::PictureBox());
			this->c53 = (gcnew System::Windows::Forms::PictureBox());
			this->c37 = (gcnew System::Windows::Forms::PictureBox());
			this->c47 = (gcnew System::Windows::Forms::PictureBox());
			this->c33 = (gcnew System::Windows::Forms::PictureBox());
			this->c55 = (gcnew System::Windows::Forms::PictureBox());
			this->c27 = (gcnew System::Windows::Forms::PictureBox());
			this->c43 = (gcnew System::Windows::Forms::PictureBox());
			this->c35 = (gcnew System::Windows::Forms::PictureBox());
			this->c51 = (gcnew System::Windows::Forms::PictureBox());
			this->c23 = (gcnew System::Windows::Forms::PictureBox());
			this->c45 = (gcnew System::Windows::Forms::PictureBox());
			this->c31 = (gcnew System::Windows::Forms::PictureBox());
			this->c03 = (gcnew System::Windows::Forms::PictureBox());
			this->c56 = (gcnew System::Windows::Forms::PictureBox());
			this->c25 = (gcnew System::Windows::Forms::PictureBox());
			this->c41 = (gcnew System::Windows::Forms::PictureBox());
			this->c36 = (gcnew System::Windows::Forms::PictureBox());
			this->c52 = (gcnew System::Windows::Forms::PictureBox());
			this->c21 = (gcnew System::Windows::Forms::PictureBox());
			this->c46 = (gcnew System::Windows::Forms::PictureBox());
			this->c32 = (gcnew System::Windows::Forms::PictureBox());
			this->c54 = (gcnew System::Windows::Forms::PictureBox());
			this->c26 = (gcnew System::Windows::Forms::PictureBox());
			this->c42 = (gcnew System::Windows::Forms::PictureBox());
			this->c34 = (gcnew System::Windows::Forms::PictureBox());
			this->c50 = (gcnew System::Windows::Forms::PictureBox());
			this->c22 = (gcnew System::Windows::Forms::PictureBox());
			this->c44 = (gcnew System::Windows::Forms::PictureBox());
			this->c30 = (gcnew System::Windows::Forms::PictureBox());
			this->c40 = (gcnew System::Windows::Forms::PictureBox());
			this->c24 = (gcnew System::Windows::Forms::PictureBox());
			this->c20 = (gcnew System::Windows::Forms::PictureBox());
			this->c06 = (gcnew System::Windows::Forms::PictureBox());
			this->c07 = (gcnew System::Windows::Forms::PictureBox());
			this->c00 = (gcnew System::Windows::Forms::PictureBox());
			this->c05 = (gcnew System::Windows::Forms::PictureBox());
			this->c02 = (gcnew System::Windows::Forms::PictureBox());
			this->c01 = (gcnew System::Windows::Forms::PictureBox());
			this->c17 = (gcnew System::Windows::Forms::PictureBox());
			this->c13 = (gcnew System::Windows::Forms::PictureBox());
			this->c15 = (gcnew System::Windows::Forms::PictureBox());
			this->c11 = (gcnew System::Windows::Forms::PictureBox());
			this->c16 = (gcnew System::Windows::Forms::PictureBox());
			this->c12 = (gcnew System::Windows::Forms::PictureBox());
			this->c14 = (gcnew System::Windows::Forms::PictureBox());
			this->c67 = (gcnew System::Windows::Forms::PictureBox());
			this->c73 = (gcnew System::Windows::Forms::PictureBox());
			this->c63 = (gcnew System::Windows::Forms::PictureBox());
			this->c65 = (gcnew System::Windows::Forms::PictureBox());
			this->c76 = (gcnew System::Windows::Forms::PictureBox());
			this->c75 = (gcnew System::Windows::Forms::PictureBox());
			this->c72 = (gcnew System::Windows::Forms::PictureBox());
			this->c71 = (gcnew System::Windows::Forms::PictureBox());
			this->c66 = (gcnew System::Windows::Forms::PictureBox());
			this->c74 = (gcnew System::Windows::Forms::PictureBox());
			this->c61 = (gcnew System::Windows::Forms::PictureBox());
			this->c64 = (gcnew System::Windows::Forms::PictureBox());
			this->c62 = (gcnew System::Windows::Forms::PictureBox());
			this->c77 = (gcnew System::Windows::Forms::PictureBox());
			this->c70 = (gcnew System::Windows::Forms::PictureBox());
			this->c60 = (gcnew System::Windows::Forms::PictureBox());
			this->c10 = (gcnew System::Windows::Forms::PictureBox());
			this->c04 = (gcnew System::Windows::Forms::PictureBox());
			this->LabelTurno = (gcnew System::Windows::Forms::Label());
			this->enter = (gcnew System::Windows::Forms::Button());
			this->istr = (gcnew System::Windows::Forms::Button());
			this->reset = (gcnew System::Windows::Forms::Button());
			this->pezzo = (gcnew System::Windows::Forms::TextBox());
			this->idRiga = (gcnew System::Windows::Forms::TextBox());
			this->idColonna = (gcnew System::Windows::Forms::TextBox());
			this->stato = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox3 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox4 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox5 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox6 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox7 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox8 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox9 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox10 = (gcnew System::Windows::Forms::PictureBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->g1 = (gcnew System::Windows::Forms::Label());
			this->g2 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->scacchiera->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c57))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c53))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c37))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c47))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c33))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c55))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c27))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c43))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c35))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c51))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c23))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c45))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c31))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c03))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c56))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c25))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c41))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c36))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c52))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c21))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c46))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c32))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c54))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c26))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c42))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c34))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c50))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c22))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c44))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c30))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c40))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c24))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c20))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c06))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c07))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c00))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c05))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c02))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c01))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c17))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c13))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c15))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c11))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c16))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c12))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c14))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c67))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c73))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c63))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c65))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c76))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c75))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c72))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c71))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c66))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c74))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c61))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c64))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c62))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c77))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c70))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c60))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c10))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c04))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox5))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox6))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox7))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox8))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox9))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox10))->BeginInit();
			this->SuspendLayout();
			// 
			// scacchiera
			// 
			this->scacchiera->BackColor = System::Drawing::Color::Transparent;
			resources->ApplyResources(this->scacchiera, L"scacchiera");
			this->scacchiera->Controls->Add(this->c57);
			this->scacchiera->Controls->Add(this->c53);
			this->scacchiera->Controls->Add(this->c37);
			this->scacchiera->Controls->Add(this->c47);
			this->scacchiera->Controls->Add(this->c33);
			this->scacchiera->Controls->Add(this->c55);
			this->scacchiera->Controls->Add(this->c27);
			this->scacchiera->Controls->Add(this->c43);
			this->scacchiera->Controls->Add(this->c35);
			this->scacchiera->Controls->Add(this->c51);
			this->scacchiera->Controls->Add(this->c23);
			this->scacchiera->Controls->Add(this->c45);
			this->scacchiera->Controls->Add(this->c31);
			this->scacchiera->Controls->Add(this->c03);
			this->scacchiera->Controls->Add(this->c56);
			this->scacchiera->Controls->Add(this->c25);
			this->scacchiera->Controls->Add(this->c41);
			this->scacchiera->Controls->Add(this->c36);
			this->scacchiera->Controls->Add(this->c52);
			this->scacchiera->Controls->Add(this->c21);
			this->scacchiera->Controls->Add(this->c46);
			this->scacchiera->Controls->Add(this->c32);
			this->scacchiera->Controls->Add(this->c54);
			this->scacchiera->Controls->Add(this->c26);
			this->scacchiera->Controls->Add(this->c42);
			this->scacchiera->Controls->Add(this->c34);
			this->scacchiera->Controls->Add(this->c50);
			this->scacchiera->Controls->Add(this->c22);
			this->scacchiera->Controls->Add(this->c44);
			this->scacchiera->Controls->Add(this->c30);
			this->scacchiera->Controls->Add(this->c40);
			this->scacchiera->Controls->Add(this->c24);
			this->scacchiera->Controls->Add(this->c20);
			this->scacchiera->Controls->Add(this->c06);
			this->scacchiera->Controls->Add(this->c07);
			this->scacchiera->Controls->Add(this->c00);
			this->scacchiera->Controls->Add(this->c05);
			this->scacchiera->Controls->Add(this->c02);
			this->scacchiera->Controls->Add(this->c01);
			this->scacchiera->Controls->Add(this->c17);
			this->scacchiera->Controls->Add(this->c13);
			this->scacchiera->Controls->Add(this->c15);
			this->scacchiera->Controls->Add(this->c11);
			this->scacchiera->Controls->Add(this->c16);
			this->scacchiera->Controls->Add(this->c12);
			this->scacchiera->Controls->Add(this->c14);
			this->scacchiera->Controls->Add(this->c67);
			this->scacchiera->Controls->Add(this->c73);
			this->scacchiera->Controls->Add(this->c63);
			this->scacchiera->Controls->Add(this->c65);
			this->scacchiera->Controls->Add(this->c76);
			this->scacchiera->Controls->Add(this->c75);
			this->scacchiera->Controls->Add(this->c72);
			this->scacchiera->Controls->Add(this->c71);
			this->scacchiera->Controls->Add(this->c66);
			this->scacchiera->Controls->Add(this->c74);
			this->scacchiera->Controls->Add(this->c61);
			this->scacchiera->Controls->Add(this->c64);
			this->scacchiera->Controls->Add(this->c62);
			this->scacchiera->Controls->Add(this->c77);
			this->scacchiera->Controls->Add(this->c70);
			this->scacchiera->Controls->Add(this->c60);
			this->scacchiera->Controls->Add(this->c10);
			this->scacchiera->Controls->Add(this->c04);
			this->scacchiera->Name = L"scacchiera";
			// 
			// c57
			// 
			resources->ApplyResources(this->c57, L"c57");
			this->c57->Name = L"c57";
			this->c57->TabStop = false;
			this->c57->Click += gcnew System::EventHandler(this, &Game::c57_Click);
			// 
			// c53
			// 
			resources->ApplyResources(this->c53, L"c53");
			this->c53->Name = L"c53";
			this->c53->TabStop = false;
			this->c53->Click += gcnew System::EventHandler(this, &Game::c53_Click);
			// 
			// c37
			// 
			resources->ApplyResources(this->c37, L"c37");
			this->c37->Name = L"c37";
			this->c37->TabStop = false;
			this->c37->Click += gcnew System::EventHandler(this, &Game::c37_Click);
			// 
			// c47
			// 
			resources->ApplyResources(this->c47, L"c47");
			this->c47->Name = L"c47";
			this->c47->TabStop = false;
			this->c47->Click += gcnew System::EventHandler(this, &Game::c47_Click);
			// 
			// c33
			// 
			resources->ApplyResources(this->c33, L"c33");
			this->c33->Name = L"c33";
			this->c33->TabStop = false;
			this->c33->Click += gcnew System::EventHandler(this, &Game::c33_Click);
			// 
			// c55
			// 
			resources->ApplyResources(this->c55, L"c55");
			this->c55->Name = L"c55";
			this->c55->TabStop = false;
			this->c55->Click += gcnew System::EventHandler(this, &Game::c55_Click);
			// 
			// c27
			// 
			resources->ApplyResources(this->c27, L"c27");
			this->c27->Name = L"c27";
			this->c27->TabStop = false;
			this->c27->Click += gcnew System::EventHandler(this, &Game::c27_Click);
			// 
			// c43
			// 
			resources->ApplyResources(this->c43, L"c43");
			this->c43->Name = L"c43";
			this->c43->TabStop = false;
			this->c43->Click += gcnew System::EventHandler(this, &Game::c43_Click);
			// 
			// c35
			// 
			resources->ApplyResources(this->c35, L"c35");
			this->c35->Name = L"c35";
			this->c35->TabStop = false;
			this->c35->Click += gcnew System::EventHandler(this, &Game::c35_Click);
			// 
			// c51
			// 
			resources->ApplyResources(this->c51, L"c51");
			this->c51->Name = L"c51";
			this->c51->TabStop = false;
			this->c51->Click += gcnew System::EventHandler(this, &Game::c51_Click);
			// 
			// c23
			// 
			resources->ApplyResources(this->c23, L"c23");
			this->c23->Name = L"c23";
			this->c23->TabStop = false;
			this->c23->Click += gcnew System::EventHandler(this, &Game::c23_Click);
			// 
			// c45
			// 
			resources->ApplyResources(this->c45, L"c45");
			this->c45->Name = L"c45";
			this->c45->TabStop = false;
			this->c45->Click += gcnew System::EventHandler(this, &Game::c45_Click);
			// 
			// c31
			// 
			resources->ApplyResources(this->c31, L"c31");
			this->c31->Name = L"c31";
			this->c31->TabStop = false;
			this->c31->Click += gcnew System::EventHandler(this, &Game::c31_Click);
			// 
			// c03
			// 
			resources->ApplyResources(this->c03, L"c03");
			this->c03->Name = L"c03";
			this->c03->TabStop = false;
			this->c03->Click += gcnew System::EventHandler(this, &Game::c03_Click);
			// 
			// c56
			// 
			resources->ApplyResources(this->c56, L"c56");
			this->c56->Name = L"c56";
			this->c56->TabStop = false;
			this->c56->Click += gcnew System::EventHandler(this, &Game::c56_Click);
			// 
			// c25
			// 
			resources->ApplyResources(this->c25, L"c25");
			this->c25->Name = L"c25";
			this->c25->TabStop = false;
			this->c25->Click += gcnew System::EventHandler(this, &Game::c25_Click);
			// 
			// c41
			// 
			resources->ApplyResources(this->c41, L"c41");
			this->c41->Name = L"c41";
			this->c41->TabStop = false;
			this->c41->Click += gcnew System::EventHandler(this, &Game::c41_Click);
			// 
			// c36
			// 
			resources->ApplyResources(this->c36, L"c36");
			this->c36->Name = L"c36";
			this->c36->TabStop = false;
			this->c36->Click += gcnew System::EventHandler(this, &Game::c36_Click);
			// 
			// c52
			// 
			resources->ApplyResources(this->c52, L"c52");
			this->c52->Name = L"c52";
			this->c52->TabStop = false;
			this->c52->Click += gcnew System::EventHandler(this, &Game::c52_Click);
			// 
			// c21
			// 
			resources->ApplyResources(this->c21, L"c21");
			this->c21->Name = L"c21";
			this->c21->TabStop = false;
			this->c21->Click += gcnew System::EventHandler(this, &Game::c21_Click);
			// 
			// c46
			// 
			resources->ApplyResources(this->c46, L"c46");
			this->c46->Name = L"c46";
			this->c46->TabStop = false;
			this->c46->Click += gcnew System::EventHandler(this, &Game::c46_Click);
			// 
			// c32
			// 
			resources->ApplyResources(this->c32, L"c32");
			this->c32->Name = L"c32";
			this->c32->TabStop = false;
			this->c32->Click += gcnew System::EventHandler(this, &Game::c32_Click);
			// 
			// c54
			// 
			resources->ApplyResources(this->c54, L"c54");
			this->c54->Name = L"c54";
			this->c54->TabStop = false;
			this->c54->Click += gcnew System::EventHandler(this, &Game::c54_Click);
			// 
			// c26
			// 
			resources->ApplyResources(this->c26, L"c26");
			this->c26->Name = L"c26";
			this->c26->TabStop = false;
			this->c26->Click += gcnew System::EventHandler(this, &Game::c26_Click);
			// 
			// c42
			// 
			resources->ApplyResources(this->c42, L"c42");
			this->c42->Name = L"c42";
			this->c42->TabStop = false;
			this->c42->Click += gcnew System::EventHandler(this, &Game::c42_Click);
			// 
			// c34
			// 
			resources->ApplyResources(this->c34, L"c34");
			this->c34->Name = L"c34";
			this->c34->TabStop = false;
			this->c34->Click += gcnew System::EventHandler(this, &Game::c34_Click);
			// 
			// c50
			// 
			resources->ApplyResources(this->c50, L"c50");
			this->c50->Name = L"c50";
			this->c50->TabStop = false;
			this->c50->Click += gcnew System::EventHandler(this, &Game::c50_Click);
			// 
			// c22
			// 
			resources->ApplyResources(this->c22, L"c22");
			this->c22->Name = L"c22";
			this->c22->TabStop = false;
			this->c22->Click += gcnew System::EventHandler(this, &Game::c22_Click);
			// 
			// c44
			// 
			resources->ApplyResources(this->c44, L"c44");
			this->c44->Name = L"c44";
			this->c44->TabStop = false;
			this->c44->Click += gcnew System::EventHandler(this, &Game::c44_Click);
			// 
			// c30
			// 
			resources->ApplyResources(this->c30, L"c30");
			this->c30->Name = L"c30";
			this->c30->TabStop = false;
			this->c30->Click += gcnew System::EventHandler(this, &Game::c30_Click);
			// 
			// c40
			// 
			resources->ApplyResources(this->c40, L"c40");
			this->c40->Name = L"c40";
			this->c40->TabStop = false;
			this->c40->Click += gcnew System::EventHandler(this, &Game::c40_Click);
			// 
			// c24
			// 
			resources->ApplyResources(this->c24, L"c24");
			this->c24->Name = L"c24";
			this->c24->TabStop = false;
			this->c24->Click += gcnew System::EventHandler(this, &Game::c24_Click);
			// 
			// c20
			// 
			resources->ApplyResources(this->c20, L"c20");
			this->c20->Name = L"c20";
			this->c20->TabStop = false;
			this->c20->Click += gcnew System::EventHandler(this, &Game::c20_Click);
			// 
			// c06
			// 
			resources->ApplyResources(this->c06, L"c06");
			this->c06->Name = L"c06";
			this->c06->TabStop = false;
			this->c06->Click += gcnew System::EventHandler(this, &Game::c06_Click);
			// 
			// c07
			// 
			resources->ApplyResources(this->c07, L"c07");
			this->c07->Name = L"c07";
			this->c07->TabStop = false;
			this->c07->Click += gcnew System::EventHandler(this, &Game::c07_Click);
			// 
			// c00
			// 
			this->c00->BackColor = System::Drawing::Color::Transparent;
			resources->ApplyResources(this->c00, L"c00");
			this->c00->Name = L"c00";
			this->c00->TabStop = false;
			this->c00->Click += gcnew System::EventHandler(this, &Game::c00_Click);
			// 
			// c05
			// 
			resources->ApplyResources(this->c05, L"c05");
			this->c05->Name = L"c05";
			this->c05->TabStop = false;
			this->c05->Click += gcnew System::EventHandler(this, &Game::c05_Click);
			// 
			// c02
			// 
			resources->ApplyResources(this->c02, L"c02");
			this->c02->Name = L"c02";
			this->c02->TabStop = false;
			this->c02->Click += gcnew System::EventHandler(this, &Game::c02_Click);
			// 
			// c01
			// 
			resources->ApplyResources(this->c01, L"c01");
			this->c01->Name = L"c01";
			this->c01->TabStop = false;
			this->c01->Click += gcnew System::EventHandler(this, &Game::c01_Click);
			// 
			// c17
			// 
			resources->ApplyResources(this->c17, L"c17");
			this->c17->Name = L"c17";
			this->c17->TabStop = false;
			this->c17->Click += gcnew System::EventHandler(this, &Game::c17_Click);
			// 
			// c13
			// 
			resources->ApplyResources(this->c13, L"c13");
			this->c13->Name = L"c13";
			this->c13->TabStop = false;
			this->c13->Click += gcnew System::EventHandler(this, &Game::c13_Click);
			// 
			// c15
			// 
			resources->ApplyResources(this->c15, L"c15");
			this->c15->Name = L"c15";
			this->c15->TabStop = false;
			this->c15->Click += gcnew System::EventHandler(this, &Game::c15_Click);
			// 
			// c11
			// 
			resources->ApplyResources(this->c11, L"c11");
			this->c11->Name = L"c11";
			this->c11->TabStop = false;
			this->c11->Click += gcnew System::EventHandler(this, &Game::c11_Click);
			// 
			// c16
			// 
			resources->ApplyResources(this->c16, L"c16");
			this->c16->Name = L"c16";
			this->c16->TabStop = false;
			this->c16->Click += gcnew System::EventHandler(this, &Game::c16_Click);
			// 
			// c12
			// 
			resources->ApplyResources(this->c12, L"c12");
			this->c12->Name = L"c12";
			this->c12->TabStop = false;
			this->c12->Click += gcnew System::EventHandler(this, &Game::c12_Click);
			// 
			// c14
			// 
			resources->ApplyResources(this->c14, L"c14");
			this->c14->Name = L"c14";
			this->c14->TabStop = false;
			this->c14->Click += gcnew System::EventHandler(this, &Game::c14_Click);
			// 
			// c67
			// 
			resources->ApplyResources(this->c67, L"c67");
			this->c67->Name = L"c67";
			this->c67->TabStop = false;
			this->c67->Click += gcnew System::EventHandler(this, &Game::c67_Click);
			// 
			// c73
			// 
			resources->ApplyResources(this->c73, L"c73");
			this->c73->Name = L"c73";
			this->c73->TabStop = false;
			this->c73->Click += gcnew System::EventHandler(this, &Game::c73_Click);
			// 
			// c63
			// 
			resources->ApplyResources(this->c63, L"c63");
			this->c63->Name = L"c63";
			this->c63->TabStop = false;
			this->c63->Click += gcnew System::EventHandler(this, &Game::c63_Click);
			// 
			// c65
			// 
			resources->ApplyResources(this->c65, L"c65");
			this->c65->Name = L"c65";
			this->c65->TabStop = false;
			this->c65->Click += gcnew System::EventHandler(this, &Game::c65_Click);
			// 
			// c76
			// 
			resources->ApplyResources(this->c76, L"c76");
			this->c76->Name = L"c76";
			this->c76->TabStop = false;
			this->c76->Click += gcnew System::EventHandler(this, &Game::c76_Click);
			// 
			// c75
			// 
			resources->ApplyResources(this->c75, L"c75");
			this->c75->Name = L"c75";
			this->c75->TabStop = false;
			this->c75->Click += gcnew System::EventHandler(this, &Game::c75_Click);
			// 
			// c72
			// 
			resources->ApplyResources(this->c72, L"c72");
			this->c72->Name = L"c72";
			this->c72->TabStop = false;
			this->c72->Click += gcnew System::EventHandler(this, &Game::c72_Click);
			// 
			// c71
			// 
			resources->ApplyResources(this->c71, L"c71");
			this->c71->Name = L"c71";
			this->c71->TabStop = false;
			this->c71->Click += gcnew System::EventHandler(this, &Game::c71_Click);
			// 
			// c66
			// 
			resources->ApplyResources(this->c66, L"c66");
			this->c66->Name = L"c66";
			this->c66->TabStop = false;
			this->c66->Click += gcnew System::EventHandler(this, &Game::c66_Click);
			// 
			// c74
			// 
			resources->ApplyResources(this->c74, L"c74");
			this->c74->Name = L"c74";
			this->c74->TabStop = false;
			this->c74->Click += gcnew System::EventHandler(this, &Game::c74_Click);
			// 
			// c61
			// 
			resources->ApplyResources(this->c61, L"c61");
			this->c61->Name = L"c61";
			this->c61->TabStop = false;
			this->c61->Click += gcnew System::EventHandler(this, &Game::c61_Click);
			// 
			// c64
			// 
			resources->ApplyResources(this->c64, L"c64");
			this->c64->Name = L"c64";
			this->c64->TabStop = false;
			this->c64->Click += gcnew System::EventHandler(this, &Game::c64_Click);
			// 
			// c62
			// 
			resources->ApplyResources(this->c62, L"c62");
			this->c62->Name = L"c62";
			this->c62->TabStop = false;
			this->c62->Click += gcnew System::EventHandler(this, &Game::c62_Click);
			// 
			// c77
			// 
			resources->ApplyResources(this->c77, L"c77");
			this->c77->Name = L"c77";
			this->c77->TabStop = false;
			this->c77->Click += gcnew System::EventHandler(this, &Game::c77_Click);
			// 
			// c70
			// 
			resources->ApplyResources(this->c70, L"c70");
			this->c70->Name = L"c70";
			this->c70->TabStop = false;
			this->c70->Click += gcnew System::EventHandler(this, &Game::c70_Click);
			// 
			// c60
			// 
			resources->ApplyResources(this->c60, L"c60");
			this->c60->Name = L"c60";
			this->c60->TabStop = false;
			this->c60->Click += gcnew System::EventHandler(this, &Game::c60_Click);
			// 
			// c10
			// 
			resources->ApplyResources(this->c10, L"c10");
			this->c10->Name = L"c10";
			this->c10->TabStop = false;
			this->c10->Click += gcnew System::EventHandler(this, &Game::c10_Click);
			// 
			// c04
			// 
			resources->ApplyResources(this->c04, L"c04");
			this->c04->Name = L"c04";
			this->c04->TabStop = false;
			this->c04->Click += gcnew System::EventHandler(this, &Game::c04_Click);
			// 
			// LabelTurno
			// 
			resources->ApplyResources(this->LabelTurno, L"LabelTurno");
			this->LabelTurno->Name = L"LabelTurno";
			// 
			// enter
			// 
			resources->ApplyResources(this->enter, L"enter");
			this->enter->Name = L"enter";
			this->enter->UseVisualStyleBackColor = true;
			this->enter->Click += gcnew System::EventHandler(this, &Game::enter_Click);
			// 
			// istr
			// 
			resources->ApplyResources(this->istr, L"istr");
			this->istr->Name = L"istr";
			this->istr->UseVisualStyleBackColor = true;
			this->istr->Click += gcnew System::EventHandler(this, &Game::istr_Click);
			// 
			// reset
			// 
			resources->ApplyResources(this->reset, L"reset");
			this->reset->Name = L"reset";
			this->reset->UseVisualStyleBackColor = true;
			this->reset->Click += gcnew System::EventHandler(this, &Game::reset_Click);
			// 
			// pezzo
			// 
			this->pezzo->CharacterCasing = System::Windows::Forms::CharacterCasing::Upper;
			resources->ApplyResources(this->pezzo, L"pezzo");
			this->pezzo->Name = L"pezzo";
			// 
			// idRiga
			// 
			this->idRiga->CharacterCasing = System::Windows::Forms::CharacterCasing::Upper;
			resources->ApplyResources(this->idRiga, L"idRiga");
			this->idRiga->Name = L"idRiga";
			// 
			// idColonna
			// 
			this->idColonna->CharacterCasing = System::Windows::Forms::CharacterCasing::Upper;
			resources->ApplyResources(this->idColonna, L"idColonna");
			this->idColonna->Name = L"idColonna";
			// 
			// stato
			// 
			this->stato->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->stato->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			resources->ApplyResources(this->stato, L"stato");
			this->stato->Name = L"stato";
			// 
			// label2
			// 
			this->label2->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			resources->ApplyResources(this->label2, L"label2");
			this->label2->Name = L"label2";
			// 
			// label3
			// 
			this->label3->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			resources->ApplyResources(this->label3, L"label3");
			this->label3->Name = L"label3";
			// 
			// label4
			// 
			this->label4->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			resources->ApplyResources(this->label4, L"label4");
			this->label4->Name = L"label4";
			// 
			// label5
			// 
			this->label5->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			resources->ApplyResources(this->label5, L"label5");
			this->label5->Name = L"label5";
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::Transparent;
			resources->ApplyResources(this->pictureBox1, L"pictureBox1");
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->TabStop = false;
			// 
			// pictureBox2
			// 
			this->pictureBox2->BackColor = System::Drawing::Color::Transparent;
			resources->ApplyResources(this->pictureBox2, L"pictureBox2");
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->TabStop = false;
			// 
			// pictureBox3
			// 
			this->pictureBox3->BackColor = System::Drawing::Color::Transparent;
			resources->ApplyResources(this->pictureBox3, L"pictureBox3");
			this->pictureBox3->Name = L"pictureBox3";
			this->pictureBox3->TabStop = false;
			// 
			// pictureBox4
			// 
			this->pictureBox4->BackColor = System::Drawing::Color::Transparent;
			resources->ApplyResources(this->pictureBox4, L"pictureBox4");
			this->pictureBox4->Name = L"pictureBox4";
			this->pictureBox4->TabStop = false;
			// 
			// pictureBox5
			// 
			this->pictureBox5->BackColor = System::Drawing::Color::Transparent;
			resources->ApplyResources(this->pictureBox5, L"pictureBox5");
			this->pictureBox5->Name = L"pictureBox5";
			this->pictureBox5->TabStop = false;
			// 
			// pictureBox6
			// 
			this->pictureBox6->BackColor = System::Drawing::Color::Transparent;
			resources->ApplyResources(this->pictureBox6, L"pictureBox6");
			this->pictureBox6->Name = L"pictureBox6";
			this->pictureBox6->TabStop = false;
			// 
			// pictureBox7
			// 
			this->pictureBox7->BackColor = System::Drawing::Color::Transparent;
			resources->ApplyResources(this->pictureBox7, L"pictureBox7");
			this->pictureBox7->Name = L"pictureBox7";
			this->pictureBox7->TabStop = false;
			// 
			// pictureBox8
			// 
			this->pictureBox8->BackColor = System::Drawing::Color::Transparent;
			resources->ApplyResources(this->pictureBox8, L"pictureBox8");
			this->pictureBox8->Name = L"pictureBox8";
			this->pictureBox8->TabStop = false;
			// 
			// pictureBox9
			// 
			this->pictureBox9->BackColor = System::Drawing::Color::Transparent;
			resources->ApplyResources(this->pictureBox9, L"pictureBox9");
			this->pictureBox9->Name = L"pictureBox9";
			this->pictureBox9->TabStop = false;
			// 
			// pictureBox10
			// 
			this->pictureBox10->BackColor = System::Drawing::Color::Transparent;
			resources->ApplyResources(this->pictureBox10, L"pictureBox10");
			this->pictureBox10->Name = L"pictureBox10";
			this->pictureBox10->TabStop = false;
			// 
			// label1
			// 
			resources->ApplyResources(this->label1, L"label1");
			this->label1->BackColor = System::Drawing::Color::Transparent;
			this->label1->Name = L"label1";
			// 
			// label6
			// 
			resources->ApplyResources(this->label6, L"label6");
			this->label6->BackColor = System::Drawing::Color::Transparent;
			this->label6->Name = L"label6";
			// 
			// label7
			// 
			resources->ApplyResources(this->label7, L"label7");
			this->label7->BackColor = System::Drawing::Color::Transparent;
			this->label7->Name = L"label7";
			// 
			// label8
			// 
			resources->ApplyResources(this->label8, L"label8");
			this->label8->BackColor = System::Drawing::Color::Transparent;
			this->label8->Name = L"label8";
			// 
			// label9
			// 
			resources->ApplyResources(this->label9, L"label9");
			this->label9->BackColor = System::Drawing::Color::Transparent;
			this->label9->Name = L"label9";
			// 
			// label10
			// 
			resources->ApplyResources(this->label10, L"label10");
			this->label10->BackColor = System::Drawing::Color::Transparent;
			this->label10->Name = L"label10";
			// 
			// label11
			// 
			resources->ApplyResources(this->label11, L"label11");
			this->label11->BackColor = System::Drawing::Color::Transparent;
			this->label11->Name = L"label11";
			// 
			// label12
			// 
			resources->ApplyResources(this->label12, L"label12");
			this->label12->BackColor = System::Drawing::Color::Transparent;
			this->label12->Name = L"label12";
			// 
			// label13
			// 
			resources->ApplyResources(this->label13, L"label13");
			this->label13->BackColor = System::Drawing::Color::Transparent;
			this->label13->Name = L"label13";
			// 
			// label14
			// 
			resources->ApplyResources(this->label14, L"label14");
			this->label14->BackColor = System::Drawing::Color::Transparent;
			this->label14->Name = L"label14";
			// 
			// g1
			// 
			resources->ApplyResources(this->g1, L"g1");
			this->g1->Name = L"g1";
			// 
			// g2
			// 
			resources->ApplyResources(this->g2, L"g2");
			this->g2->Name = L"g2";
			// 
			// label15
			// 
			resources->ApplyResources(this->label15, L"label15");
			this->label15->Name = L"label15";
			// 
			// Game
			// 
			resources->ApplyResources(this, L"$this");
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::Info;
			this->Controls->Add(this->label15);
			this->Controls->Add(this->g2);
			this->Controls->Add(this->g1);
			this->Controls->Add(this->label14);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label13);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label12);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->pictureBox10);
			this->Controls->Add(this->pictureBox8);
			this->Controls->Add(this->pictureBox6);
			this->Controls->Add(this->pictureBox4);
			this->Controls->Add(this->pictureBox3);
			this->Controls->Add(this->pictureBox9);
			this->Controls->Add(this->pictureBox7);
			this->Controls->Add(this->pictureBox5);
			this->Controls->Add(this->pictureBox2);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->stato);
			this->Controls->Add(this->reset);
			this->Controls->Add(this->istr);
			this->Controls->Add(this->enter);
			this->Controls->Add(this->idColonna);
			this->Controls->Add(this->idRiga);
			this->Controls->Add(this->pezzo);
			this->Controls->Add(this->LabelTurno);
			this->Controls->Add(this->scacchiera);
			this->MaximizeBox = false;
			this->Name = L"Game";
			this->TopMost = true;
			this->scacchiera->ResumeLayout(false);
			this->scacchiera->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c57))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c53))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c37))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c47))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c33))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c55))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c27))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c43))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c35))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c51))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c23))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c45))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c31))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c03))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c56))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c25))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c41))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c36))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c52))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c21))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c46))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c32))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c54))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c26))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c42))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c34))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c50))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c22))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c44))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c30))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c40))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c24))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c20))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c06))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c07))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c00))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c05))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c02))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c01))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c17))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c13))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c15))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c11))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c16))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c12))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c14))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c67))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c73))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c63))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c65))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c76))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c75))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c72))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c71))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c66))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c74))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c61))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c64))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c62))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c77))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c70))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c60))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c10))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->c04))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox5))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox6))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox7))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox8))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox9))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox10))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	

///		Funzioni che passano la casella cliccata e le sue rispettive coordinate nella rispettiva funzione di gioco

private: System::Void c00_Click(System::Object^  sender, System::EventArgs^  e) {

	// row col
	mainGame(0, 0, c00);

}
private: System::Void c01_Click(System::Object^  sender, System::EventArgs^  e) {

	// row col
	mainGame(0, 1, c01);
}
private: System::Void c02_Click(System::Object^  sender, System::EventArgs^  e) {

	// row col
	mainGame(0, 2, c02);
}
private: System::Void c03_Click(System::Object^  sender, System::EventArgs^  e) {

	// row col
	mainGame(0, 3, c03);
}
private: System::Void c04_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(0, 4, c04);
}
private: System::Void c05_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(0, 5, c05);
}
private: System::Void c06_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(0, 6, c06);
}
private: System::Void c07_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(0, 7, c07);
}
private: System::Void c10_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(1, 0, c10);
}
private: System::Void c11_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(1, 1, c11);
}
private: System::Void c12_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(1, 2, c12);
}
private: System::Void c13_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(1, 3, c13);
}
private: System::Void c14_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(1, 4, c14);
}
private: System::Void c15_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(1, 5, c15);
}
private: System::Void c16_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(1, 6, c16);
}
private: System::Void c17_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(1, 7, c17);
}
private: System::Void c20_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(2, 0, c20);
}
private: System::Void c21_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(2, 1, c21);
}
private: System::Void c22_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(2, 2, c22);
}
private: System::Void c23_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(2, 3, c23);
}
private: System::Void c24_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(2, 4, c24);
}
private: System::Void c25_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(2, 5, c25);
}
private: System::Void c26_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(2, 6, c26);
}
private: System::Void c27_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(2, 7, c27);
}
private: System::Void c30_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(3, 0, c30);
}
private: System::Void c31_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(3, 1, c31);
}
private: System::Void c32_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(3, 2, c32);
}
private: System::Void c33_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(3, 3, c33);
}
private: System::Void c34_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(3, 4, c34);
}
private: System::Void c35_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(3, 5, c35);
}
private: System::Void c36_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(3, 6, c36);
}
private: System::Void c37_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(3, 7, c37);
}
private: System::Void c40_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(4, 0, c40);
}
private: System::Void c41_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(4, 1, c41);
}
private: System::Void c42_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(4, 2, c42);
}
private: System::Void c43_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(4, 3, c43);
}
private: System::Void c44_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(4, 4, c44);
}
private: System::Void c45_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(4, 5, c45);
}
private: System::Void c46_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(4, 6, c46);
}
private: System::Void c47_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(4, 7, c47);
}
private: System::Void c50_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(5, 0, c50);
}
private: System::Void c51_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(5, 1, c51);
}
private: System::Void c52_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(5, 2, c52);
}
private: System::Void c53_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(5, 3, c53);
}
private: System::Void c54_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(5, 4, c54);
}
private: System::Void c55_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(5, 5, c55);
}
private: System::Void c56_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(5, 6, c56);
}
private: System::Void c57_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(5, 7, c57);
}
private: System::Void c60_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(6, 0, c60);
}
private: System::Void c61_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(6, 1, c61);
}
private: System::Void c62_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(6, 2, c62);
}
private: System::Void c63_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(6, 3, c63);
}
private: System::Void c64_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(6, 4, c64);
}
private: System::Void c65_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(6, 5, c65);
}
private: System::Void c66_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(6, 6, c66);
}
private: System::Void c67_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(6, 7, c67);
}
private: System::Void c70_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(7, 0, c70);
}
private: System::Void c71_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(7, 1, c71);
}
private: System::Void c72_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(7, 2, c72);
}
private: System::Void c73_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(7, 3, c73);
}
private: System::Void c74_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(7, 4, c74);
}
private: System::Void c75_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(7, 5, c75);
}
private: System::Void c76_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(7, 6, c76);
}
private: System::Void c77_Click(System::Object^  sender, System::EventArgs^  e) {
	// row col
	mainGame(7, 7, c77);
}
private: System::Void enter_Click(System::Object^  sender, System::EventArgs^  e) {		// Tasto enter della console

	bool err = false;			// tiene conto in caso di mancata sovrascrittura di errori successivi, l'esecuzione andr� a buon fine (err = false)

	///!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! crasha all'inserimento di una lettera

/*	if (colore->Text != "") {				// controllo stringa vuota

		coloreConsole = System::Convert::ToInt16(colore->Text);		// inserisce il valore della textbox

	}
	else {

		stato->Text = "errore input colore";		// errore associato
		err = true;
	}
*/

	if (pezzo->Text != "") {				// controllo stringa vuota

		pezzoConsole = System::Convert::ToInt16(pezzo->Text);		// inserisce il valore della textbox

	}
	else {

		stato->Text = "errore input pezzo";		// errore associato
		err = true;
	}

	if (idColonna->Text != "") {				// controllo stringa vuota

		colConsole = System::Convert::ToInt16(idColonna->Text);		// inserisce il valore della textbox

	}
	else {

		stato->Text = "errore input colonna";		// errore associato
		err = true;
	}
	
	if (idRiga->Text != "") {				// controllo stringa vuota

		rowConsole = System::Convert::ToInt16(idRiga->Text);		// inserisce il valore della textbox

	}
	else {

		stato->Text = "errore input riga";		// errore associato
		err = true;
	}

	/// controlli sui dati								!!!!!!!!!!!!!! non andavano i controlli con !=
/*
	if (coloreConsole > 1 || coloreConsole < 0) {		// controllo sul colore	

		colore->Text = "";
		stato->Text = "errore input colore";		// errore associato
		err = true;
	}
*/
	if (pezzoConsole < 2 || pezzoConsole > 6)			// controllo sul pezzo nero
		if (!(pezzoConsole == 0 || pezzoConsole == 10))
			if (pezzoConsole < 22 || pezzoConsole > 26)				// controllo sul pezzo bianco
				if (!(pezzoConsole == 30)) {

					pezzo->Text = "";
					stato->Text = "errore input pezzo";		// errore associato
					err = true;

				}

	if (colConsole < 0 || colConsole > 7) {		// controllo sugli indici			

		idColonna->Text = "";
		stato->Text = "errore input indici";		// errore associato
		err = true;
	}

	if(rowConsole < 0 || rowConsole > 7) {		// controllo sugli indici			

		idRiga->Text = "";
		stato->Text = "errore input indici";		// errore associato
		err = true;
	}



	/// ESECUZIONE comando

	if (!err) {				// se la variabile di errore rimane false (con ! --> true) allora si esegue il comando!

		S[rowConsole][colConsole] = pezzoConsole;			// all'indice passato, inserisco il valore passato
		refreshScacchiera();
		stato->Text = "Comando eseguito!";

	}


	//MessageBox::Show("colore: " + coloreConsole);				// DEBUG

}
private: System::Void istr_Click(System::Object^  sender, System::EventArgs^  e) {

	// istruzioni pulsante ?
	MessageBox::Show("La console serve per creare combinazioni di pezzi scelte dall'utente per provare ogni possibile combinazione!\n\nCome usare la console?\n\n1. Inserire il valore associato ai pezzi:\n\t>> 0 per CASELLA VUOTA\n\tPEZZI NERI:\n\t\t>> 2 per il PEDONE\n\t\t>> 3 per la TORRE\n\t\t>> 4 per il CAVALLO\n\t\t>> 5 per l'ALFIERE\n\t\t>> 6 per la REGINA\n\t\t>> 10 per il RE\n\tPEZZI BIANCHI:\n\t\t>> 22 per il PEDONE\n\t\t>> 23 per la TORRE\n\t\t>> 24 per il CAVALLO\n\t\t>> 25 per l'ALFIERE\n\t\t>> 26 per la REGINA\n\t\t>> 30 per il RE\n2. Inserire l'indice di riga e colonna tenendo conto che la scacchiera � una matrice 8*8 con indici tra 0 e 7.\n\nIl bottone di RESET serve a ripristinare la scacchiera, INVIO per eseguire il comando, la casella di testo indica se � stato correttamente eseguito il comando.\nErrori:\n\t>> *errore input* per gli errori nell'inserimento dei dati", "ISTRUZIONI CONSOLE");

}

private: System::Void reset_Click(System::Object^  sender, System::EventArgs^  e) {

	stato->Text = "Reset scacchiera!";		// notifica il reset

	azzeramentoScacchiera();			// azzera tutta la scacchiera in caso di reset
	
	refreshScacchiera();			//richiama il refresh

}

};
}
